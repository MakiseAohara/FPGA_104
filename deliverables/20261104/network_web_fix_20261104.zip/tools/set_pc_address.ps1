﻿$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'network-change.log'
try {
    Start-Transcript -Path $log -Append | Out-Null
    $nic = Get-NetAdapter -Name '以太网 3'
    if ($nic.InterfaceDescription -ne 'Realtek Gaming USB 2.5GbE Family Controller') {
        throw 'Adapter does not match the inspected board connection.'
    }
    $existing = Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4
    if (-not ($existing | Where-Object IPAddress -eq '169.254.47.62')) {
        New-NetIPAddress -InterfaceIndex $nic.ifIndex -IPAddress '169.254.47.62' -PrefixLength 16 | Out-Null
    }
    # Local link only: keep WLAN, gateway and DNS unchanged.
    if (-not (Get-NetFirewallRule -Name 'FPGA104-PC-HTTP-8090' -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -Name 'FPGA104-PC-HTTP-8090' -DisplayName 'FPGA104 PC monitor 8090 local link' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8090 -LocalAddress '169.254.47.62' -RemoteAddress LocalSubnet -InterfaceAlias $nic.Name | Out-Null
    }
    if (-not (Get-NetFirewallRule -Name 'FPGA104-UDP-8080' -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -Name 'FPGA104-UDP-8080' -DisplayName 'FPGA104 board telemetry local link' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 8080 -RemoteAddress '169.254.47.63' -InterfaceAlias $nic.Name | Out-Null
    }
    Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 | Format-Table IPAddress,PrefixLength,AddressState
    'SUCCESS' | Set-Content (Join-Path $PSScriptRoot 'network-change.result')
} catch {
    $_ | Out-String | Add-Content $log
    $_ | Out-String | Set-Content (Join-Path $PSScriptRoot 'network-change.result')
    exit 1
} finally { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
