/*==============================================================================
 * mot_core.h — 多目标跟踪（IOU Tracker）+ 行为预测      v1.5（按 10/31 任务书重写门控）
 *
 * 纯 C（无平台依赖、无动态内存），固件与电脑端测试共用。
 * 输入：每帧 96x96 uint8 灰度（固件里就是 AI 输入的那张图，字节原样 u）
 * 输出：多目标轨迹（稳定 ID）/ 速度向量 / 下一位置预测 / 到达 ROI 的剩余帧数
 *
 * 处理链：
 *   1) 背景建模：bg += (cur-bg)>>BG_SHIFT（α=1/32，与 RTL 帧差背景同思路），
 *      整幅均值补偿掉 AGC/增益跳变，避免误检整幅
 *   2) 前景：mask = |cur-bg| >= MOT_DIFF_THR，再做 3x3 膨胀把人体合成整块
 *   3) 鬼影剔除：连通域内"当前帧差分"像素太少 ⇒ 是背景残留（人走了），丢弃
 *   4) 连通域：4 邻域 flood fill（栈式，无递归），按面积降序取前 MOT_MAX_DET 个
 *   5) 关联：正确框 IoU + 运动/外观门控，全局枚举两目标匹配
 *   6) 速度：质心位移的 EMA（Q4 定点，16 = 1 px/帧）
 *   7) 预测：统一物理时间模型，默认前视 400ms（legacy名义步200ms）
 *
 * 单位：坐标/面积是 96x96 网格上的像素；速度 Q4（右移 4 位得 px/帧）。
 *============================================================================*/
#ifndef MOT_CORE_H
#define MOT_CORE_H

#include <string.h>
#include <stdint.h>

#define MOT_HAS_TIMED_API 1
#define MOT_HAS_GROUP_OCCLUSION 1
#define MOT_TIME_STEP_MS 200
#define MOT_MAX_TIME_GAP_MS 5000
#define MOT_MAX_OCCLUSION_MS 4000

#define MOT_W            96
#define MOT_H            96
#define MOT_N            (MOT_W * MOT_H)

#define MOT_MAX_DET      6
#define MOT_MAX_TRK      2       /* v2.1：现场最多 2 人；4 会容纳超分割产生的虚警轨（3~4群 占 22~27%） */
#define MOT_TRAJ_LEN     12      /* 每目标保留的轨迹点数 */

#define MOT_DIFF_THR     14      /* 与背景的差阈值（拉伸后画面） */
#define MOT_MOTION_THR   10      /* 帧间差分阈值（鬼影剔除用） */
#ifndef MOT_MERGE_PX
#define MOT_MERGE_PX        14   /* v2.0：两条航迹质心距离 <= 该值（px）且面积相近 => 合并 */
#endif
#ifndef MOT_NEWTRK_IOU
#define MOT_NEWTRK_IOU   320   /* 千分比：新检测与已确认航迹（含外推框）IoU >= 该值 => 视为同一目标，不再新建航迹 */
#endif
#ifndef MOT_MERGE_IOU
#define MOT_MERGE_IOU     300   /* 千分比：旧判据（对切分两半恒不触发，已废弃，仅保留作关闭开关） */
#define MOT_MERGE_Y_OVERLAP 80  /* v2.1：两框竖向带交叠 >= 较小框高度的 80% 才并 */
#endif
#ifndef MOT_MERGE_AREA_HI
#define MOT_MERGE_AREA_HI  170   /* v2.0：面积比上限（%） */
#endif
#ifndef MOT_MERGE_ADJ_GAP
#define MOT_MERGE_ADJ_GAP   0    /* v3.10：切分两半的水平间隙上限（px），<=0 关闭该判据 */
#endif
#ifndef MOT_SPLIT_MIN_SEP
#define MOT_SPLIT_MIN_SEP    12  /* v2.0：切开后左右两半质心至少相距该值（px），否则不切（v2.1: 9->12，减少超分割） */
#endif
#ifndef MOT_SPLIT_HALF_H
#define MOT_SPLIT_HALF_H    60   /* v2.0：切开后每一半高度 >= 整块高度的 60% 才认 */
#endif
#ifndef MOT_SPLIT_MIN_W
#define MOT_SPLIT_MIN_W  20
#endif      /* v1.9：宽度 >= 该值的连通域才尝试"两人粘连"切分 */
#ifndef MOT_SPLIT_MIN_ASPECT
#define MOT_SPLIT_MIN_ASPECT 70  /* 宽度/高度 >= 70% 才认为"像两个人并肩"（单人约 30~40%） */
#endif
#ifndef MOT_SPLIT_MAX_ASPECT
#define MOT_SPLIT_MAX_ASPECT 170 /* 宽度/高度 <= 170%：再宽就是背景墙条，不是两个并肩的人 */
#endif
#ifndef MOT_SPLIT_MIN_H
#define MOT_SPLIT_MIN_H  12
#endif
#define MOT_SPLIT_VALLEY 45      /* 谷深：切分列像素数 <= 峰值 * 45%（v2.1: 35->45，要求更明显的谷才切） */
#define MOT_MIN_AREA     60      /* 最小目标面积（膨胀后 px）：暗场噪点约 20-50 */
#define MOT_MIN_PERSON_AREA 150  /* v3.6：页面"人数"只数面积达标的框（<150 是噪点/反光） */
#define MOT_MIN_PERSON_H    12   /* v3.6：且高度 >=12（96 格里 12.5%，8 m 外的人也比他高） */
#define MOT_MAX_AREA     9000    /* 最大目标面积：人贴近镜头可占整幅九成，只有"整幅全变"才丢 */
#define MOT_IOU_THR      200     /* IOU 阈值，千分比（200 = 0.20） */
#ifndef MOT_MAX_MISS
#define MOT_MAX_MISS     6       /* v1.3 Bug3：已确认航迹丢失 6 帧内可复用 ID（2fps ≈3 s） */
#endif
/* v16 options (from evidence/session_1103/mot_v16.patch).
   GATE evidence: 18 serial logs, 96 tracked boxes -> 15.6% of boxes are full-frame
   (w,h >= 90% of the 96x96 frame) and ALL 15 of them happen on frames where the AI
   reports "no person". A full-frame blob is a global light/foreground change, not a
   person, so it should not create a new track. GATE is therefore ON by default.
   KEEP stays OFF: tracks in the recorded logs rarely miss frames, so widening
   MAX_MISS has no supporting data yet. */
#ifndef MOT_V16_GATE
#define MOT_V16_GATE     1
#endif
#ifndef MOT_V16_KEEP
#define MOT_V16_KEEP     0
#endif
#ifndef MOT_MAX_MISS_KEEP
#define MOT_MAX_MISS_KEEP 10
#endif
#ifndef MOT_V16_GATE_RATIO_N
#define MOT_V16_GATE_RATIO_N 9   /* 0.9 */
#endif
#ifndef MOT_V16_GATE_RATIO_D
#define MOT_V16_GATE_RATIO_D 10
#endif
#ifndef MOT_REPORT_MISS
#define MOT_REPORT_MISS  1       /* 丢失超过该帧数就不上报（仍留在表里等重连） */
#endif
#define MOT_CONFIRM_HITS 2       /* 连续命中多少帧算确认目标 */
#define MOT_HORIZON      2       /* nominal 200ms steps: default horizon 400ms */
#define MOT_GATE_PX      16      /* 二级关联：质心距离门限（IOU 全丢失时按速度外推后仍可续轨） */
#define MOT_BG_SHIFT     5       /* 背景更新 α = 1/(1<<5) */
#define MOT_GHOST_DIV    8       /* 连通域内运动像素 < 面积/该值 ⇒ 判鬼影（要求 ≥12.5% 像素在动） */
#define MOT_GHOST_IOU    300     /* v1.3 Bug1：与已确认航迹当前框 IOU ≥ 0.30 时不做鬼影剔除（千分比） */
#define MOT_GHOST_GATE   10      /* v1.3 Bug1：连通域质心距已确认航迹质心 ≤ 该值也不剔除（px） */
#define MOT_MAX_MISS_UNCONF 3    /* v1.3 Bug3：未确认航迹丢失 3 帧即删 */
#define MOT_REID_PX      25      /* 旧 ID 复用半径（px） */
#define MOT_SUP_MAX      3       /* v1.8 #2：连续 3 帧无支撑就不输出/不预警（更严） */
#define MOT_SHAKE_N      3       /* v1.7 #3：连续多少帧整幅前景判为"相机被移动" */
#define MOT_GRAY_TOL     28      /* v1.7 #4：重连时允许的平均灰度差 */
#define MOT_AREA_LO      50      /* v1.7 #4：重连时面积比下限（%） */
#define MOT_AREA_HI      200     /* v1.7 #4：重连时面积比上限（%） */
#define MOT_P_PERSON     60      /* v1.5 Bug1：AI 判人阈值（p>=60 视为人体证据） */
#define MOT_STILL_MAX    20      /* v1.6：仅靠红外豁免时，静止目标最多保 20 帧（≈10 s），防止箱子/家具长期占轨 */
#define MOT_IR_NEED      2       /* v1.5 Bug1：红外 10 帧内热计数阈值（与固件 IR_NEED 对齐） */

/* 行为预测用的 ROI：画面中间 2/3（进入这块才算"进入画面主体"） */
/* v3.11：ETA/提前唤醒专用关注区（画面中段），与"报警区"解耦 —— 报警区是整幅，
   但"预测还有几帧进入关注区"必须有一个有限的目标区，否则 eta 恒为 -1。 */
/* v17：靠近镜头 -> 预测到"贴脸"的帧数（离线实测：面积增长比质心速度稳） */
#ifndef MOT_NEAR_PCT
#define MOT_NEAR_PCT    55
#endif
#ifndef MOT_ARATE_MIN
#define MOT_ARATE_MIN   4     /* v17.2：>=4%/帧才算"在靠近"（离线自检 tools/eta_sim.py 得出） */
#endif
/* v17.1（默认关闭，等有操作者的两次上板对比再开）：
   关联门限随目标尺寸放大 —— 整幅框(96 高)的人一步能跳出 MOT_GATE_PX=16，旧门限必然换号。
   MOT_GATE_SIZE_DIV = 3 表示 gate = max(MOT_GATE_PX, 框宽/3)。 */
#ifndef MOT_GATE_SIZE_DIV
#define MOT_GATE_SIZE_DIV 0
#endif
#ifndef MOT_PRED_DAMP_N
#define MOT_PRED_DAMP_N 1     /* shared prediction scale; no hidden half-speed display */
#endif
#ifndef MOT_PRED_DAMP_D
#define MOT_PRED_DAMP_D 1
#endif
#ifndef MOT_ETA_X0
#define MOT_ETA_X0      24
#define MOT_ETA_Y0      24
#define MOT_ETA_X1      72
#define MOT_ETA_Y1      72
#endif

#define MOT_ROI_X0       0       /* v3.0: 报警区扩到整幅（原 16..80 只认中心） */
#define MOT_ROI_Y0       0
#define MOT_ROI_X1       95
#define MOT_ROI_Y1       95

typedef struct {
   short x0, y0, x1, y1;   /* 闭区间包围盒 */
   short cx, cy;           /* 质心 */
   short area;
   short mean;             /* v1.7 #4：连通域平均灰度（重连时比对） */
} mot_det_t;

typedef struct {
   short id;
   short x0, y0, x1, y1;   /* 当前框 */
   short cx, cy;           /* 当前质心 */
   short vx, vy;           /* 速度 Q4（px/帧 ×16） */
   short px, py;           /* 前视预测位置（质心 + v*HORIZON） */
   short dir;              /* 0=静止 1=左 2=右 3=上 4=下 5=斜移 */
   short hits, misses, age;
   short confirmed;
   short active;             /* 本帧是否在场（misses <= MOT_REPORT_MISS） */
   short sup;                /* v1.7 #2：连续无支撑帧数 */
   short supported;          /* v1.7 #2：本帧是否有 AI/红外/运动支撑 */
   short mean;               /* v1.7 #4：平均灰度 */
   short still;              /* 连续静止帧数（速度≈0） */
   short area;               /* v3.11：上一帧面积（判"正在靠近"） */
   short grow;               /* v3.11：连续面积增长帧数 */
   short arate;              /* v17：面积增长率 EMA（%/帧），用于"还有几帧贴脸" */
   short grow2;              /* v17.2：连续"在变大"（>=3%/帧）的帧数 */
   short full;               /* v3.6：整幅检测（>80% 宽且 >80% 高）——光照突变，不是人 */
   short eta;              /* 预计还有几帧进入 ROI；-1=不会进/已在 ROI */
   short occluded;          /* ambiguous merged observation, never reported as measured */
   short obs_cx, obs_cy;    /* last measured center, never overwritten by coast */
   unsigned short obs_elapsed_ms;
   unsigned short sample_ms; /* interval of the current update */
   short traj_n;
   short traj[MOT_TRAJ_LEN][2];
} mot_trk_t;

typedef struct {
   int n_det;                        /* 本帧有效检测数 */
   int raw_area;                     /* 滤波前最大连通域面积（诊断） */
   short raw_box[4];                 /* v1.3 Bug2：最大连通域包围盒（整幅前景时直接当检测） */
   short raw_cx, raw_cy;
   short big_reset, big_full;        /* v1.5 Bug2 诊断：整幅前景时是 coast 还是复位背景 */
   int ai_p, ir_cnt;                 /* 本帧人体/红外证据 */
   const unsigned char* cur;         /* v1.7 #4：本帧像素（算平均灰度） */
   int shake_cnt;                    /* v1.7 #3：连续整幅前景帧数（相机被移动） */
   short shaking;                    /* v1.7 #3：本帧判定为"相机移动中" */
   mot_det_t det[MOT_MAX_DET];
   int n_trk;                        /* 当前航迹数（含未确认） */
   mot_trk_t trk[MOT_MAX_TRK];
   int next_id;
   int frame;
   unsigned int dt_ms;
   uint32_t timestamp_ms;
   unsigned char time_valid, timed_call;
   int last_area;
   unsigned short bg_q8[MOT_N]; /* fractional background, symmetric updates */
   unsigned char bg[MOT_N];          /* 背景模型 */
   unsigned char prev[MOT_N];        /* 上一帧（鬼影剔除用） */
   int have_prev;
} mot_ctx_t;

typedef struct {
   unsigned char mask[MOT_N];
   unsigned char dmask[MOT_N];
   unsigned short lab[MOT_N];
   short stack[MOT_N];
} mot_work_t;

static void mot_reset(mot_ctx_t* c)
{
   if (!c) return;
   memset(c, 0, sizeof(*c));
   c->next_id = 1;
   c->dt_ms = MOT_TIME_STEP_MS;
}

static void mot_set_background(mot_ctx_t* c,const unsigned char* cur)
{
   int i;memcpy(c->bg,cur,MOT_N);
   for(i=0;i<MOT_N;i++)c->bg_q8[i]=(unsigned short)((unsigned int)cur[i]*256u);
}

/* ---------------- 1)+2) 背景差分 → 前景 mask ---------------- */
static void mot_foreground(mot_ctx_t* c, mot_work_t* w, const unsigned char* cur)
{
   int i, x, y;
   long sc = 0, sb = 0;
   int delta;

   for (i = 0; i < MOT_N; ++i) { sc += cur[i]; sb += c->bg[i]; }
   delta = (int)((sc - sb) / MOT_N);              /* 整幅亮度补偿 */

   for (i = 0; i < MOT_N; ++i) {
      int b = (int)c->bg[i] + delta;
      int d;
      if (b < 0) b = 0; if (b > 255) b = 255;
      d = (int)cur[i] - b;
      w->mask[i] = ((d >= MOT_DIFF_THR) || (d <= -MOT_DIFF_THR)) ? 1u : 0u;
      if (c->have_prev) {
         int m = (int)cur[i] - (int)c->prev[i];
         w->dmask[i] = ((m >= MOT_MOTION_THR) || (m <= -MOT_MOTION_THR)) ? 1u : 0u;
      } else {
         w->dmask[i] = 0u;
      }
   }

   /* 3x3 膨胀：把人体边缘的碎片合成整块（两邻域已够，避免收成骨架） */
   for (y = 1; y < MOT_H - 1; ++y) {
      const int row = y * MOT_W;
      for (x = 1; x < MOT_W - 1; ++x) {
         const int i = row + x;
         if (w->mask[i]) continue;
         /* 只看种子（==1），不把本次膨胀出来的 2 当种子，否则会沿扫描方向级联填满 */
         if (w->mask[i-1] == 1u || w->mask[i+1] == 1u ||
             w->mask[i-MOT_W] == 1u || w->mask[i+MOT_W] == 1u)
            w->mask[i] = 2u;                      /* 2 = 膨胀补出来的，稍后统一成 1 */
      }
   }
   for (i = 0; i < MOT_N; ++i) if (w->mask[i] == 2u) w->mask[i] = 1u;
}

/* 背景更新：在"被判为背景"的像素上快速跟上，前景像素上慢速（保留记忆） */
static void mot_bg_update(mot_ctx_t* c, mot_work_t* w, const unsigned char* cur)
{
   int i;
   for (i = 0; i < MOT_N; ++i) {
      const int b = (int)c->bg_q8[i];
      const int d = (int)cur[i]*256 - b;
      const int sh = w->mask[i] ? (MOT_BG_SHIFT + 2) : MOT_BG_SHIFT;
      /* A supported foreground is the target, not a slowly changing wall.
         Learning it creates a trail behind moving people and drags centroids.
         Unsupported stationary changes still adapt using the slower rate. */
      if(w->mask[i] && (c->ai_p>=MOT_P_PERSON || c->ir_cnt>=MOT_IR_NEED))continue;
      c->bg_q8[i]=(unsigned short)(b+d/(1<<sh));
      c->bg[i]=(unsigned char)(((unsigned int)c->bg_q8[i]+128u)/256u);
   }
   memcpy(c->prev, cur, MOT_N);
   c->have_prev = 1;
}

/* v1.3 Bug1：连通域是否与某个"已确认航迹"的当前框重合（IOU≥0.30 或质心足够近） */
static int mot_hit_confirmed(const mot_ctx_t* c, int x0, int y0, int x1, int y1, int cx, int cy,
                              int ai_p, int ir_cnt)
{
   int k;
   for (k = 0; k < c->n_trk; ++k) {
      const mot_trk_t* t = &c->trk[k];
      int ix0, iy0, ix1, iy1;
      if (!t->confirmed) continue;
      /* v1.6 Bug1：AI 明确判人 → 站着不动也保；只靠红外 → 最多保 MOT_STILL_MAX 帧（箱子/家具不会长期占轨） */
      if (!(ai_p >= MOT_P_PERSON || (ir_cnt >= MOT_IR_NEED && t->still <= MOT_STILL_MAX))) continue;
      ix0 = x0 > t->x0 ? x0 : t->x0;
      iy0 = y0 > t->y0 ? y0 : t->y0;
      ix1 = x1 < t->x1 ? x1 : t->x1;
      iy1 = y1 < t->y1 ? y1 : t->y1;
      if (ix1 >= ix0 && iy1 >= iy0) {
         const long inter = (long)(ix1 - ix0 + 1) * (iy1 - iy0 + 1);
         const long ua = (long)(x1 - x0 + 1) * (y1 - y0 + 1)
                       + (long)(t->x1 - t->x0 + 1) * (t->y1 - t->y0 + 1) - inter;
         if (ua > 0 && inter * 1000 / ua >= MOT_GHOST_IOU) return 1;
      }
      {
         int dx = cx - (int)t->cx, dy = cy - (int)t->cy;
         if (dx < 0) dx = -dx;
         if (dy < 0) dy = -dy;
         /* 质心近还要面积可比，否则人体周边的碎片也会被当成"静止目标"放过，导致 ID 碎裂 */
         if ((dx > dy ? dx : dy) <= MOT_GHOST_GATE &&
             (long)(x1 - x0 + 1) * (y1 - y0 + 1) * 2 >= (long)(t->x1 - t->x0 + 1) * (t->y1 - t->y0 + 1)) return 1;
      }
   }
   return 0;
}

/* ---------------- 4) 连通域 ---------------- */
#ifdef MOT_TEST_DEBUG
typedef struct { int calls, area_rej, ghost_rej, dup_rej, ok, last_mov, last_area, last_split, merged, t_pair, t_dist, t_area, t_iou; } mot_dbg_t;
static mot_dbg_t mot_dbg;
#endif
static int mot_push_det(mot_ctx_t* c, int x0, int y0, int x1, int y1,
                        int area, long sumx, long sumy, long sumv, int mov)
{
   int q, n = c->n_det;
#ifdef MOT_TEST_DEBUG
   mot_dbg.calls++; mot_dbg.last_mov = mov; mot_dbg.last_area = area;
#endif
   if (area < MOT_MIN_AREA || area > MOT_MAX_AREA) {
#ifdef MOT_TEST_DEBUG
      mot_dbg.area_rej++;
#endif
      return 0;
   }
   /* v1.3 Bug1：静止目标（站着不动）没有帧间运动，会被鬼影判据丢掉；
      只要这个连通域和"已确认航迹"的当前框对得上，就跳过鬼影过滤。 */
   if (mov * MOT_GHOST_DIV < area &&
       !mot_hit_confirmed(c, x0, y0, x1, y1, (int)(sumx / area), (int)(sumy / area),
                          c->ai_p, c->ir_cnt)) {
#ifdef MOT_TEST_DEBUG
      mot_dbg.ghost_rej++;
#endif
      return 0;
   }
   if (n >= MOT_MAX_DET) return 0;
   for (q = 0; q < n; ++q) {
      /* v1.3：同一个人的重复连通域（膨胀后会裂开）只留大的，避免一帧内新建多条航迹 */
      const int ix0 = x0 > c->det[q].x0 ? x0 : c->det[q].x0;
      const int iy0 = y0 > c->det[q].y0 ? y0 : c->det[q].y0;
      const int ix1 = x1 < c->det[q].x1 ? x1 : c->det[q].x1;
      const int iy1 = y1 < c->det[q].y1 ? y1 : c->det[q].y1;
      if (ix1 >= ix0 && iy1 >= iy0) {
         const long inter = (long)(ix1 - ix0 + 1) * (iy1 - iy0 + 1);
         const long ua = (long)(x1 - x0 + 1) * (y1 - y0 + 1)
                       + (long)(c->det[q].x1 - c->det[q].x0 + 1)
                         * (long)(c->det[q].y1 - c->det[q].y0 + 1) - inter;
         if (ua > 0 && inter * 1000 / ua >= 500) {
#ifdef MOT_TEST_DEBUG
            mot_dbg.dup_rej++;
#endif
            return 0;
         }
      }
   }
   c->det[n].x0 = (short)x0; c->det[n].y0 = (short)y0;
   c->det[n].x1 = (short)x1; c->det[n].y1 = (short)y1;
   c->det[n].cx = (short)(sumx / area);
   c->det[n].cy = (short)(sumy / area);
   c->det[n].area = (short)area;
   c->det[n].mean = (short)(c->cur ? sumv / area : 0);
   c->n_det = n + 1;
#ifdef MOT_TEST_DEBUG
   mot_dbg.ok++;
#endif
   return 1;
}

/* v1.9 ④：两个人挨着走时前景会粘成一个连通域，检测层就只剩 1 个目标。
   这里看列投影：在中间 1/3 里找"谷"，够深就沿该列切成左右两块分别上报。 */
static int mot_find_split(const mot_work_t* w, unsigned short id,
                          int x0, int y0, int x1, int y1, int area)
{
   short col[MOT_W];
   int x, y, peak = 0, lo, hi, best = -1, bestv = 0;
   long la = 0, ra = 0;
   const int wd = x1 - x0 + 1, ht = y1 - y0 + 1;
   if (wd < MOT_SPLIT_MIN_W || ht < MOT_SPLIT_MIN_H) return -1;
   if (wd * 100 < ht * MOT_SPLIT_MIN_ASPECT) return -1;   /* 单个人：宽高比远小于 0.7，不切 */
   if (wd * 100 > ht * MOT_SPLIT_MAX_ASPECT) return -1;   /* 背景墙条：宽高比过大，不切 */
   if (area < 2 * MOT_MIN_AREA) return -1;
   for (x = x0; x <= x1; ++x) col[x] = 0;
   for (y = y0; y <= y1; ++y) {
      const int base = y * MOT_W;
      for (x = x0; x <= x1; ++x) if (w->lab[base + x] == id) col[x]++;
   }
   for (x = x0; x <= x1; ++x) if (col[x] > peak) peak = col[x];
   if (peak <= 0) return -1;
   lo = x0 + wd / 3; hi = x1 - wd / 3;
   if (hi <= lo) return -1;
   best = lo; bestv = col[lo];
   for (x = lo; x <= hi; ++x) if (col[x] < bestv) { bestv = col[x]; best = x; }
   if (bestv * 100 > peak * MOT_SPLIT_VALLEY) return -1;   /* 谷不够深 ⇒ 是一个人 */
   for (x = x0; x <= best; ++x) la += col[x];
   for (x = best + 1; x <= x1; ++x) ra += col[x];
   if (la < MOT_MIN_AREA || ra < MOT_MIN_AREA) return -1;  /* 一侧太窄 ⇒ 不切 */
   return best;
}

static int mot_label(mot_work_t* w, mot_ctx_t* c)
{
   int i, n_id = 0;
   c->raw_area = 0;
   c->n_det = 0;
   memset(w->lab, 0, sizeof(w->lab));
   for (i = 0; i < MOT_N; ++i) {
      int sp = 0, area = 0, mov = 0;
      long sumv = 0, sx = 0, sy = 0;
      int x0 = MOT_W, y0 = MOT_H, x1 = -1, y1 = -1;
      unsigned short id;
      int xs;
      if (!w->mask[i] || w->lab[i]) continue;
      id = (unsigned short)(++n_id);
      w->lab[i] = id;
      w->stack[sp++] = (short)i;
      while (sp > 0) {
         const int p = w->stack[--sp];
         const int px = p % MOT_W, py = p / MOT_W;
         area++;
         if (w->dmask[p]) mov++;
         if (c->cur) sumv += c->cur[p];
         sx += px; sy += py;
         if (px < x0) x0 = px;
         if (px > x1) x1 = px;
         if (py < y0) y0 = py;
         if (py > y1) y1 = py;
         {
            const int nb[4] = { p - 1, p + 1, p - MOT_W, p + MOT_W };
            const int ok[4] = { px > 0, px < MOT_W - 1, py > 0, py < MOT_H - 1 };
            int k;
            for (k = 0; k < 4; ++k) {
               const int q = nb[k];
               if (ok[k] && w->mask[q] && !w->lab[q]) {
                  w->lab[q] = id;
                  w->stack[sp++] = (short)q;
               }
            }
         }
      }
      if (area > c->raw_area) {
         c->raw_area = area;
         c->raw_box[0] = (short)x0; c->raw_box[1] = (short)y0;
         c->raw_box[2] = (short)x1; c->raw_box[3] = (short)y1;
         c->raw_cx = (short)(sx / area); c->raw_cy = (short)(sy / area);
      }
      xs = mot_find_split(w, id, x0, y0, x1, y1, area);
#ifdef MOT_TEST_DEBUG
   if (xs >= 0) mot_dbg.last_split = xs;
#endif
      if (xs >= 0) {
         long la = 0, lb = 0, lax = 0, lay = 0, lbx = 0, lby = 0, lav = 0, lbv = 0;
         int lmov = 0, rmov = 0;
         int lx0 = MOT_W, ly0 = MOT_H, lx1 = -1, ly1 = -1;
         int rx0 = MOT_W, ry0 = MOT_H, rx1 = -1, ry1 = -1;
         int y, x;
         for (y = y0; y <= y1; ++y) for (x = x0; x <= x1; ++x) {
            const int p = y * MOT_W + x;
            if (w->lab[p] != id) continue;
            if (x <= xs) {
               la++; lax += x; lay += y;
               if (c->cur) lav += c->cur[p];
               if (w->dmask[p]) lmov++;
               if (x < lx0) lx0 = x; if (x > lx1) lx1 = x;
               if (y < ly0) ly0 = y; if (y > ly1) ly1 = y;
            } else {
               lb++; lbx += x; lby += y;
               if (c->cur) lbv += c->cur[p];
               if (w->dmask[p]) rmov++;
               if (x < rx0) rx0 = x; if (x > rx1) rx1 = x;
               if (y < ry0) ry0 = y; if (y > ry1) ry1 = y;
            }
         }
         if (la >= MOT_MIN_AREA && lb >= MOT_MIN_AREA && lx1 >= lx0 && rx1 >= rx0) {
            /* v2.0：两半必须"够远、够高"才认是两个人，否则仍按一个人上报 */
            const int sep_ok = (lax / la - lbx / lb) >= MOT_SPLIT_MIN_SEP ||
                               (lbx / lb - lax / la) >= MOT_SPLIT_MIN_SEP;
            const int h_ok = (ly1 - ly0 + 1) * 100 >= (y1 - y0 + 1) * MOT_SPLIT_HALF_H &&
                             (ry1 - ry0 + 1) * 100 >= (y1 - y0 + 1) * MOT_SPLIT_HALF_H;
            if (sep_ok && h_ok) {
               mot_push_det(c, lx0, ly0, lx1, ly1, (int)la, lax, lay, lav, lmov);
               mot_push_det(c, rx0, ry0, rx1, ry1, (int)lb, lbx, lby, lbv, rmov);
               continue;
            }
         }
      }
      mot_push_det(c, x0, y0, x1, y1, area, sx, sy, sumv, mov);
   }
   {
      int a, b;
      for (a = 0; a < c->n_det; ++a) for (b = a + 1; b < c->n_det; ++b) {
         if (c->det[b].area > c->det[a].area) {
            const mot_det_t tt = c->det[a];
            c->det[a] = c->det[b];
            c->det[b] = tt;
         }
      }
   }
   c->last_area = (c->n_det > 0) ? (int)c->det[0].area : 0;
   return c->n_det;
}

/* ---------------- IOU（千分比） ---------------- */
static int mot_iou(const mot_det_t* a, const short* b)
{
   const int ix0 = a->x0 > b[0] ? a->x0 : b[0];
   const int iy0 = a->y0 > b[1] ? a->y0 : b[1];
   const int ix1 = a->x1 < b[2] ? a->x1 : b[2];
   const int iy1 = a->y1 < b[3] ? a->y1 : b[3];
   int inter, ua;
   if (ix1 < ix0 || iy1 < iy0) return 0;
   inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1);
   ua = (int)(a->x1-a->x0+1)*(a->y1-a->y0+1)
      + (b[2]-b[0]+1)*(b[3]-b[1]+1) - inter;
   if (ua <= 0) return 0;
   return inter * 1000 / ua;
}

/* vx/vy remain Q4 pixels per nominal 200 ms, including timed updates.
   Prediction is in wall time; all consumers use this one motion model. */
static void mot_predict_position_ms(const mot_trk_t* t, unsigned int ms, int* x, int* y)
{
   int64_t sx=(int64_t)t->vx*(int64_t)ms*MOT_PRED_DAMP_N/(16L*MOT_TIME_STEP_MS*MOT_PRED_DAMP_D);
   int64_t sy=(int64_t)t->vy*(int64_t)ms*MOT_PRED_DAMP_N/(16L*MOT_TIME_STEP_MS*MOT_PRED_DAMP_D);
   *x=(int)t->cx+(int)sx; *y=(int)t->cy+(int)sy;
}

/* ---------------- 5)~7) 关联 / 生命周期 / 速度 / 预测 ---------------- */
static int mot_eta_frames(const mot_trk_t* t)
{
   int best = -1;
   /* ① 靠近镜头：面积按 arate %/帧 增长 → 估算距离"近景阈值"还有几帧。
      人往镜头走时框一直在变大，这条比质心速度更早、更稳地给出提前量。 */
   if (t->grow2 >= 2 && t->arate >= MOT_ARATE_MIN && t->area > 0) {
      const long tgt = (long)MOT_W * MOT_H * MOT_NEAR_PCT / 100;
      long a = t->area;
      int k;
      best = 60;                       /* 60 帧内到不了 = "还早"，比 -1 更好判断 */
      for (k = 1; k <= 60; ++k) {
         a += a * t->arate / 100;
         if (a >= tgt) { best = k; break; }
         if (a > (long)MOT_W * MOT_H) { best = k; break; }
      }
   }
   /* ② 位置：不在 ROI 里时，按速度外推看几帧后能进 ROI（横向跑进来的人） */
   if (!(t->cx >= MOT_ETA_X0 && t->cx <= MOT_ETA_X1 &&
         t->cy >= MOT_ETA_Y0 && t->cy <= MOT_ETA_Y1)) {
      int k;
      for (k = 1; k <= MOT_HORIZON + 4; ++k) {
         int x,y;
         mot_predict_position_ms(t,(unsigned int)k*MOT_TIME_STEP_MS,&x,&y);
         if (x >= MOT_ETA_X0 && x <= MOT_ETA_X1 && y >= MOT_ETA_Y0 && y <= MOT_ETA_Y1) {
            if (best < 0 || k < best) best = k;
            break;
         }
         if (x < 0 || x >= MOT_W || y < 0 || y >= MOT_H) break;
      }
   }
   return best;
}

/* 命中后更新航迹（速度 = 质心位移 EMA，Q4） */
static void mot_update_track(mot_ctx_t* c, int bt, int bd)
{
   mot_trk_t* t = &c->trk[bt];
   const mot_det_t* d = &c->det[bd];
   const int dx = (int)d->cx - (int)t->obs_cx;
   const int dy = (int)d->cy - (int)t->obs_cy;
   const unsigned int elapsed=t->obs_elapsed_ms ? t->obs_elapsed_ms : MOT_TIME_STEP_MS;
   int mx=(int)((int64_t)dx*16*MOT_TIME_STEP_MS/(int64_t)elapsed);
   int my=(int)((int64_t)dy*16*MOT_TIME_STEP_MS/(int64_t)elapsed);
   if(mx>16*MOT_W)mx=16*MOT_W;if(mx< -16*MOT_W)mx= -16*MOT_W;
   if(my>16*MOT_H)my=16*MOT_H;if(my< -16*MOT_H)my= -16*MOT_H;
   if(t->hits<=1 || t->misses>0) { t->vx=(short)mx;t->vy=(short)my; }
   else { t->vx=(short)(((int)t->vx+mx)/2);t->vy=(short)(((int)t->vy+my)/2); }
   t->obs_cx=d->cx;t->obs_cy=d->cy;t->obs_elapsed_ms=0;t->occluded=0;
   /* 整幅检测（人贴近镜头）不参与速度更新，否则质心跳变会算出几百 px/帧 的假速度 */
   t->full = ((int)(d->x1 - d->x0 + 1) > MOT_W * 4 / 5 &&
              (int)(d->y1 - d->y0 + 1) > MOT_H * 4 / 5) ? 1 : 0;
   if (t->full) {
      t->vx = (short)0; t->vy = (short)0;
   }
   if (t->vx > -8 && t->vx < 8 && t->vy > -8 && t->vy < 8) { if (t->still < 32000) t->still++; }
   else t->still = 0;
   {   /* v3.11：面积连续变大 = 正在靠近镜头（比质心速度稳） */
      const int ar = (int)(d->x1 - d->x0 + 1) * (int)(d->y1 - d->y0 + 1);
      if (t->area > 0 && ar * 100 > (int)t->area * 108) { if (t->grow < 32000) t->grow++; }
      else if (t->area > 0 && ar * 100 < (int)t->area * 96) t->grow = 0;
      if (t->area > 0) {                      /* v17.2：面积增长率 EMA（%/帧） */
         int r = (ar * 100) / (int)t->area - 100;
         if (r > 60) r = 60;
         if (r < -60) r = -60;
         t->arate = (short)(((int)t->arate * 3 + r) / 4);
         if (r > 0 && (int)t->arate < r) t->arate = (short)r;   /* 变大立即跟上，变小慢慢降 */
         if (r >= 3) { if (t->grow2 < 32000) t->grow2++; }
         else if (r <= 0) t->grow2 = 0;
      }
      t->area = (short)(ar > 32767 ? 32767 : ar);
   }
   t->x0 = d->x0; t->y0 = d->y0; t->x1 = d->x1; t->y1 = d->y1;
   t->cx = d->cx; t->cy = d->cy;
   if (t->hits < 32000) t->hits++;
   t->age++;
   t->misses = 0;
   if (t->hits >= MOT_CONFIRM_HITS) t->confirmed = 1;
   t->active = 1;
   t->mean = d->mean;
   /* v1.7 #2：AI 判人 / 红外仍热 / 自身在动 → 有支撑；否则累计无支撑帧数 */
   if (c->ai_p >= MOT_P_PERSON ||
       t->vx <= -24 || t->vx >= 24 || t->vy <= -24 || t->vy >= 24) {
      t->sup = 0;
   } else if (t->sup < 32000) {
      t->sup++;
   }
   t->supported = (t->sup <= MOT_SUP_MAX) ? 1 : 0;
   if (t->traj_n >= MOT_TRAJ_LEN) {
      memmove(&t->traj[0][0], &t->traj[1][0], sizeof(short) * 2 * (MOT_TRAJ_LEN - 1));
      t->traj_n = MOT_TRAJ_LEN - 1;
   }
   t->traj[t->traj_n][0] = t->cx;
   t->traj[t->traj_n][1] = t->cy;
   t->traj_n++;
}

/* 用当前速度把航迹框外推 k 帧（k 用 Q4 定点 16=1 帧），写进 b4 并返回预测质心 */
static void mot_predict_box(const mot_trk_t* t, int kq4, short* b4, int* pcx, int* pcy)
{
   int x,y;
   unsigned int step=t->sample_ms ? t->sample_ms : MOT_TIME_STEP_MS;
   unsigned int ms=(unsigned int)((long)step*kq4/16);
   int sx,sy;
   mot_predict_position_ms(t,ms,&x,&y);sx=x-t->cx;sy=y-t->cy;
   b4[0]=(short)(t->x0+sx);b4[1]=(short)(t->y0+sy);
   b4[2]=(short)(t->x1+sx);b4[3]=(short)(t->y1+sy);
   *pcx=x;*pcy=y;
}

static int mot_iou4(const mot_det_t* d, const short* b4)
{
   const int ix0 = d->x0 > b4[0] ? d->x0 : b4[0];
   const int iy0 = d->y0 > b4[1] ? d->y0 : b4[1];
   const int ix1 = d->x1 < b4[2] ? d->x1 : b4[2];
   const int iy1 = d->y1 < b4[3] ? d->y1 : b4[3];
   int inter, ua;
   if (ix1 < ix0 || iy1 < iy0) return 0;
   inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1);
   ua = (int)(d->x1-d->x0+1)*(d->y1-d->y0+1)
      + (b4[2]-b4[0]+1)*(b4[3]-b4[1]+1) - inter;
   if (ua <= 0) return 0;
   return inter * 1000 / ua;
}

/* v2.0：一人多轨合并（防御性）。实测：切分产生的左右两半是"相邻"关系，IoU 常 <0.30，
   本函数很少触发；真正把 ID 抖动压下来的是 mot_find_split 的两道门槛（最小间距/最低高度）。 */
static void mot_merge_tracks(mot_ctx_t* c)
{
   int i,j;
   for(i=0;i<c->n_trk;i++)for(j=i+1;j<c->n_trk;j++) {
      mot_trk_t* a=&c->trk[i];mot_trk_t* b=&c->trk[j];
      mot_det_t d;short box[4];
      /* Established independent tracks keep their IDs through close passes.
         Only nearly identical unconfirmed observations can be duplicate births. */
      if(a->confirmed || b->confirmed || a->misses || b->misses)continue;
      memset(&d,0,sizeof(d));d.x0=a->x0;d.y0=a->y0;d.x1=a->x1;d.y1=a->y1;
      box[0]=b->x0;box[1]=b->y0;box[2]=b->x1;box[3]=b->y1;
      if(mot_iou4(&d,box)>=850) {
         if(a->hits>=b->hits)b->misses=MOT_MAX_MISS+1;
         else a->misses=MOT_MAX_MISS+1;
      }
   }
}

/* Pair-level gates apply before optimization, including high-IoU pairs. */
static int mot_pair_cost(const mot_ctx_t* c,int track,int det)
{
   const mot_trk_t* t=&c->trk[track];const mot_det_t* d=&c->det[det];
   short box[4];int x,y,dx,dy,dist,gate,area0,area1,ratio,gray,iou;
   mot_predict_box(t,16,box,&x,&y);
   dx=d->cx-x;if(dx<0)dx=-dx;dy=d->cy-y;if(dy<0)dy=-dy;
   dist=(dx>dy?dx:dy)+((dx+dy)>>2);
   area0=(t->x1-t->x0+1)*(t->y1-t->y0+1);
   area1=(d->x1-d->x0+1)*(d->y1-d->y0+1);
   if(area0<=0 || area1<=0)return -1;
   ratio=(int)((long)area1*100/area0);
   gray=d->mean-t->mean;if(gray<0)gray=-gray;
   if(ratio<MOT_AREA_LO || ratio>MOT_AREA_HI || gray>MOT_GRAY_TOL)return -1;
   gate=(t->confirmed && t->misses>0)?MOT_REID_PX:MOT_GATE_PX;
   if(c->dt_ms>MOT_TIME_STEP_MS)gate+=(int)(c->dt_ms/MOT_TIME_STEP_MS)-1;
   if(gate>48)gate=48;
   iou=mot_iou4(d,box);
   if(dist>gate)return -1;
   if(iou<MOT_IOU_THR && dist>gate*3/4)return -1;
   return 1000-iou+dist*25+gray*6+(ratio>100?ratio-100:100-ratio)*3;
}

static void mot_associate(mot_ctx_t* c)
{
   static unsigned char det_used[MOT_MAX_DET];
   static unsigned char trk_used[MOT_MAX_TRK];
   int i, k;

   for (i = 0; i < c->n_det; ++i) det_used[i] = 0;
   for (i = 0; i < c->n_trk; ++i) trk_used[i] = 0;

   /* Accumulate elapsed time since the last measurement before association. */
   for(k=0;k<c->n_trk;k++) {
      unsigned int dt=c->dt_ms ? c->dt_ms : MOT_TIME_STEP_MS;
      unsigned int elapsed=c->trk[k].obs_elapsed_ms+dt;
      c->trk[k].obs_elapsed_ms=(unsigned short)(elapsed>60000?60000:elapsed);
      c->trk[k].sample_ms=(unsigned short)dt;
   }
   /* A single blob spanning two established predictions is not a measurement
      of either person's center. Preserve both motion states through that finite
      ambiguity, and let global assignment reconnect them after separation. */
   if(c->n_trk==2 && c->n_det==1 && c->trk[0].confirmed && c->trk[1].confirmed) {
      int ax,ay,bx,by;short box[4];
      mot_predict_box(&c->trk[0],16,box,&ax,&ay);
      mot_predict_box(&c->trk[1],16,box,&bx,&by);
      for(i=0;i<c->n_det;i++) {
         mot_det_t* d=&c->det[i];
         int aw=c->trk[0].x1-c->trk[0].x0+1,bw=c->trk[1].x1-c->trk[1].x0+1;
         int wide=d->x1-d->x0+1;
         int established_merge=c->trk[0].occluded && c->trk[1].occluded;
         if(ax>=d->x0 && ax<=d->x1 && ay>=d->y0 && ay<=d->y1 &&
            bx>=d->x0 && bx<=d->x1 && by>=d->y0 && by<=d->y1 &&
            (established_merge || (wide*10>(aw>bw?aw:bw)*13))) {
            det_used[i]=1;c->trk[0].occluded=1;c->trk[1].occluded=1;
         }
      }
   }
   /* With two tracks at most, exhaustive assignment is small (<=49 choices).
      Optimize cardinality first and the joint motion/IoU/appearance cost next. */
   if(c->n_trk<=2) {
      int a,b,besta=-1,bestb=-1,bestn=-1,bestcost=0x7fffffff;
      int cost[MOT_MAX_TRK][MOT_MAX_DET];
      for(k=0;k<c->n_trk;k++)for(i=0;i<c->n_det;i++)cost[k][i]=det_used[i] ? -1 : mot_pair_cost(c,k,i);
      for(a=-1;a<c->n_det;a++)for(b=-1;b<c->n_det;b++) {
         int n=0,sum=0;
         if(c->n_trk==0 && (a!=-1 || b!=-1))continue;
         if(c->n_trk==1 && b!=-1)continue;
         if(a>=0) {if(cost[0][a]<0)continue;n++;sum+=cost[0][a];}
         if(b>=0) {if(b==a || cost[1][b]<0)continue;n++;sum+=cost[1][b];}
         if(n>bestn || (n==bestn && sum<bestcost)) {bestn=n;bestcost=sum;besta=a;bestb=b;}
      }
      if(besta>=0) {det_used[besta]=1;trk_used[0]=1;mot_update_track(c,0,besta);}
      if(bestb>=0) {det_used[bestb]=1;trk_used[1]=1;mot_update_track(c,1,bestb);}
   }
   /* 未匹配航迹：丢失 + 按速度外推（人走两步再回来仍保留 ID） */
   /* 未匹配航迹：丢失 + 按速度外推（人走两步再回来仍保留 ID） */
   for (k = 0; k < c->n_trk; ++k) {
      mot_trk_t* t = &c->trk[k];
      if (trk_used[k]) continue;
      if (t->misses < 32000) t->misses++;
      t->age++;
      t->active = (t->misses <= MOT_REPORT_MISS) ? 1 : 0;
      if (c->ai_p >= MOT_P_PERSON) t->sup = 0;
      else if (t->sup < 32000) t->sup++;
      t->supported = (t->sup <= MOT_SUP_MAX) ? 1 : 0;
      {
         int dcx,dcy;
         mot_predict_position_ms(t,t->sample_ms,&dcx,&dcy);
         const int px = dcx - (t->x0 + t->x1) / 2;
         const int py = dcy - (t->y0 + t->y1) / 2;
         t->x0 = (short)(t->x0 + px); t->x1 = (short)(t->x1 + px);
         t->y0 = (short)(t->y0 + py); t->y1 = (short)(t->y1 + py);
         t->cx = (short)(dcx < 0 ? 0 : (dcx > MOT_W - 1 ? MOT_W - 1 : dcx));
         t->cy = (short)(dcy < 0 ? 0 : (dcy > MOT_H - 1 ? MOT_H - 1 : dcy));
         if (t->x0 < 0) t->x0 = 0;
         if (t->y0 < 0) t->y0 = 0;
         if (t->x1 > MOT_W - 1) t->x1 = MOT_W - 1;
         if (t->y1 > MOT_H - 1) t->y1 = MOT_H - 1;
      }
   }

   /* 未匹配检测：新建航迹（v2.1：先排除"其实就是已有确认航迹"的检测，避免一人多轨） */
   for (i = 0; i < c->n_det; ++i) {
      mot_trk_t* t;
      int dup_of_trk = 0;
      if (det_used[i]) continue;
      for (k = 0; k < c->n_trk; ++k) {
         short b4[4]; int pcx, pcy;
         if (!c->trk[k].confirmed || !c->trk[k].active) continue;
         mot_predict_box(&c->trk[k], 16, b4, &pcx, &pcy);
         if (mot_iou4(&c->det[i], b4) >= MOT_NEWTRK_IOU) { dup_of_trk = 1; break; }
      }
      if (dup_of_trk) continue;
#if MOT_V16_GATE
      {   /* 整幅大块 + AI 判无人 → 不建新航迹 */
         const int bw = (int)c->det[i].x1 - (int)c->det[i].x0 + 1;
         const int bh = (int)c->det[i].y1 - (int)c->det[i].y0 + 1;
         if (bw * MOT_V16_GATE_RATIO_D >= MOT_W * MOT_V16_GATE_RATIO_N &&
             bh * MOT_V16_GATE_RATIO_D >= MOT_H * MOT_V16_GATE_RATIO_N &&
             c->ai_p < MOT_P_PERSON) continue;
      }
#endif
      if (c->n_trk >= MOT_MAX_TRK) {
         int victim = -1, j;
         for (j = 0; j < c->n_trk; ++j) if (!c->trk[j].confirmed) { victim = j; break; }
         if (victim < 0) continue;
         memmove(&c->trk[victim], &c->trk[victim + 1], sizeof(mot_trk_t) * (MOT_MAX_TRK - victim - 1));
         c->n_trk--;
      }
      t = &c->trk[c->n_trk++];
      memset(t, 0, sizeof(*t));
      t->id = (short)c->next_id++;
      t->x0 = c->det[i].x0; t->y0 = c->det[i].y0;
      t->x1 = c->det[i].x1; t->y1 = c->det[i].y1;
      t->cx = c->det[i].cx; t->cy = c->det[i].cy;
      t->obs_cx=t->cx;t->obs_cy=t->cy;t->obs_elapsed_ms=0;
      t->sample_ms=(unsigned short)(c->dt_ms ? c->dt_ms : MOT_TIME_STEP_MS);
      t->area=(short)((t->x1-t->x0+1)*(t->y1-t->y0+1));
      t->hits = 1; t->age = 1; t->traj_n = 1; t->active = 1; t->supported = 1; t->mean = c->det[i].mean;
      t->traj[0][0] = t->cx; t->traj[0][1] = t->cy;
   }

   /* v2.0：先把"同一目标的多条航迹"合并，再执行删除 */
   mot_merge_tracks(c);

   /* 删除丢失过久的航迹 */
   {
      int wr = 0;
      for (k = 0; k < c->n_trk; ++k) {
#if MOT_V16_KEEP
         const int miss_limit = c->trk[k].confirmed
             ? ((c->ai_p >= MOT_P_PERSON) ? MOT_MAX_MISS_KEEP : MOT_MAX_MISS)
             : MOT_MAX_MISS_UNCONF;
#else
         const int miss_limit = (c->trk[k].occluded && c->trk[k].obs_elapsed_ms<=MOT_MAX_OCCLUSION_MS)
             ? 32000 : (c->trk[k].confirmed ? MOT_MAX_MISS : MOT_MAX_MISS_UNCONF);
#endif
         if (c->trk[k].misses > miss_limit) continue;
         if (wr != k) c->trk[wr] = c->trk[k];
         wr++;
      }
      c->n_trk = wr;
   }

   /* 预测 + 方向 + ROI 到达时间 */
   for (k = 0; k < c->n_trk; ++k) {
      mot_trk_t* t = &c->trk[k];
      const int ax = (int)t->vx, ay = (int)t->vy;
      int px,py;
      mot_predict_position_ms(t,MOT_HORIZON*MOT_TIME_STEP_MS,&px,&py);
      t->px=(short)px;t->py=(short)py;
      if (ax > -8 && ax < 8 && ay > -8 && ay < 8) t->dir = 0;
      else if ((ax >= 8 || ax <= -8) && (ay >= 8 || ay <= -8)) t->dir = 5;
      else if (ax >= 8) t->dir = 2;
      else if (ax <= -8) t->dir = 1;
      else if (ay <= -8) t->dir = 3;
      else t->dir = 4;
      t->eta = (short)mot_eta_frames(t);
   }
}

/* 当前在场的确认航迹数（丢失中的不算；整幅光照突变不算） */
static int mot_active_confirmed(const mot_ctx_t* c)
{
   int k, n = 0;
   for (k = 0; k < c->n_trk; ++k) {
      if (c->trk[k].confirmed && c->trk[k].active && !c->trk[k].full) n++;
   }
   return n;
}

/* v3.6 "画面里有几个人"。页面原来显示 n_trk（航迹表大小，含正在丢失的航迹和噪点），
   所以会出现"一个人显示两个人""人走了还显示一个人"。这里只数：
   - 本帧真的看到（misses==0，不是靠 coast 撑着）
   - 框够大（面积 >=150 且高 >=12）
   - 整幅框（>=80% 宽且 >=80% 高）需要 AI 判人有 或 红外热，否则按光照突变/自动曝光处理
   - 同一个人的两块（谷切分、或一块被另一块包住）只算一个 */
static int mot_fresh_confirmed(const mot_ctx_t* c)
{
   short bx0[MOT_MAX_TRK], by0[MOT_MAX_TRK], bx1[MOT_MAX_TRK], by1[MOT_MAX_TRK];
   const int human = (c->ai_p >= 0) || (c->ir_cnt > 0);
   int k, j, n = 0;
   for (k = 0; k < c->n_trk; ++k) {
      const mot_trk_t* t = &c->trk[k];
      const int w = (int)t->x1 - (int)t->x0 + 1;
      const int h = (int)t->y1 - (int)t->y0 + 1;
      if (!t->confirmed || !t->active || t->misses != 0) continue;
      if (w * h < MOT_MIN_PERSON_AREA || h < MOT_MIN_PERSON_H) continue;
      if (w * 5 >= MOT_W * 4 && h * 5 >= MOT_H * 4 && !human) continue;
      bx0[n] = t->x0; by0[n] = t->y0; bx1[n] = t->x1; by1[n] = t->y1; n++;
      if (n >= MOT_MAX_TRK) break;
   }
   for (k = 0; k < n; ++k) {
      for (j = k + 1; j < n; ++j) {
         if (bx1[k] < 0 || bx1[j] < 0) continue;
         {
            const int hk = by1[k] - by0[k] + 1, hj = by1[j] - by0[j] + 1;
            const int hm = hk < hj ? hk : hj;
            const int oy0 = by0[k] > by0[j] ? by0[k] : by0[j];
            const int oy1 = by1[k] < by1[j] ? by1[k] : by1[j];
            const int oy = oy1 - oy0 + 1;
            const int gap = (bx0[j] > bx1[k]) ? (bx0[j] - bx1[k] - 1)
                           : ((bx0[k] > bx1[j]) ? (bx0[k] - bx1[j] - 1) : 0);
            const int ix0 = bx0[k] > bx0[j] ? bx0[k] : bx0[j];
            const int ix1 = bx1[k] < bx1[j] ? bx1[k] : bx1[j];
            const int iy0 = by0[k] > by0[j] ? by0[k] : by0[j];
            const int iy1 = by1[k] < by1[j] ? by1[k] : by1[j];
            const int iw = ix1 - ix0 + 1, ih = iy1 - iy0 + 1;
            const int ak = hk * (bx1[k] - bx0[k] + 1), aj = hj * (bx1[j] - bx0[j] + 1);
            const int am = ak < aj ? ak : aj;
            const int inter = (iw > 0 && ih > 0) ? iw * ih : 0;
            /* Adjacency alone is not identity evidence: two people can be close. */
            const int cont = (am > 0 && inter * 20 >= am * 17);    /* 一块基本包住另一块（>=85%） */
            if (cont) { /* Disjoint adjacent detections may be two real people. */
               bx1[k] = (short)(bx1[k] > bx1[j] ? bx1[k] : bx1[j]);
               bx0[k] = (short)(bx0[k] < bx0[j] ? bx0[k] : bx0[j]);
               by1[k] = (short)(by1[k] > by1[j] ? by1[k] : by1[j]);
               by0[k] = (short)(by0[k] < by0[j] ? by0[k] : by0[j]);
               bx1[j] = (short)-1;
            }
         }
      }
   }
   j = 0;
   for (k = 0; k < n; ++k) if (bx1[k] >= 0) j++;
   return j;
}

/* v3.11：有目标正在靠近镜头（面积连续 3 帧变大） */
static int mot_approach(const mot_ctx_t* c)
{
   int k;
   for (k = 0; k < c->n_trk; ++k) {
      const mot_trk_t* t = &c->trk[k];
      if (t->confirmed && t->active && t->grow >= 3 && !t->full) return 1;
   }
   return 0;
}

/* 在动且已确认的航迹数（静止的箱子/家具不算"人体证据"） */
static int mot_moving_confirmed(const mot_ctx_t* c)
{
   int k, n = 0;
   for (k = 0; k < c->n_trk; ++k) {
      if (c->trk[k].confirmed && c->trk[k].active && c->trk[k].still <= 6) n++;
   }
   return n;
}

/* 一站式：返回本帧航迹数
 * ai_p：本帧 AI 人体分数（int8，-128..127）；<0 视为"AI 判无人"，>=0 视为"AI 判有人"。
 *       v1.3 Bug2 用它决定"整幅前景"是光照突变（重置背景）还是人贴近镜头（输出整幅检测）。 */
static int mot_step(mot_ctx_t* c, mot_work_t* w, const unsigned char* cur, int ai_p, int ir_cnt)
{
   if (!c || !w || !cur) return 0;
   if(!c->timed_call)c->dt_ms=MOT_TIME_STEP_MS;
   if (!c->have_prev && c->frame == 0) {
      /* 第一帧：只建背景 */
      mot_set_background(c,cur);
      memcpy(c->prev, cur, MOT_N);
      c->have_prev = 1;
      c->frame++;
      return 0;
   }
   c->big_reset = 0; c->big_full = 0;
   c->ai_p = ai_p; c->ir_cnt = ir_cnt;
   c->cur = cur;
   mot_foreground(c, w, cur);
   mot_label(w, c);

   /* v1.5 Bug2：整幅前景（面积 > MOT_MAX_AREA）——
      不再丢帧、不再指望 1/128 的背景更新自己恢复：
      · 沿用上一帧的轨迹做预测（coast），本帧不产生新检测；
      · 只有 AI 判无人 且 红外也不热 时，才把背景快速重置为当前帧。 */
   /* v1.7 #3：整幅大位移 = 相机被移动。期间不出新航迹、不预警，画面稳定后再重建背景与航迹。 */
   if (c->raw_area > MOT_MAX_AREA) {
      c->shake_cnt++;
   } else {
      if (c->shake_cnt >= MOT_SHAKE_N) {
         c->n_trk = 0;              /* 抖完重建：丢掉抖动期间的全部航迹 */
         c->next_id = c->next_id < 1000 ? c->next_id : 1;
         c->big_reset = 1;
      }
      c->shake_cnt = 0;
   }
   c->shaking = (c->shake_cnt >= MOT_SHAKE_N) ? 1 : 0;

   if (c->raw_area > MOT_MAX_AREA) {
      c->n_det = 0;
      c->last_area = 0;
      c->big_full = 1;
      if (ai_p < 0 && ir_cnt < MOT_IR_NEED) {
         mot_set_background(c,cur);
         memcpy(c->prev, cur, MOT_N);
         c->have_prev = 1;
         c->big_reset = 1;
      }
      if (c->n_trk > MOT_MAX_TRK) c->n_trk = MOT_MAX_TRK;
      mot_associate(c);          /* n_det=0 ⇒ 所有航迹按速度外推（coast） */
      c->frame++;
      return c->n_trk;
   }

   mot_bg_update(c, w, cur);
   if (c->n_trk > MOT_MAX_TRK) c->n_trk = MOT_MAX_TRK;
   mot_associate(c);
   c->frame++;
   return c->n_trk;
}

/* New callers supply capture time; legacy mot_step retains a fixed 200 ms step.
   Duplicate or backwards timestamps do not advance state. A long discontinuity
   starts a fresh background/track segment instead of inventing huge velocities. */
static int mot_step_timed(mot_ctx_t* c,mot_work_t* w,const unsigned char* cur,
                          int ai_p,int ir_cnt,uint32_t timestamp_ms)
{
   unsigned int dt=MOT_TIME_STEP_MS;int n;
   if(!c || !w || !cur)return 0;
   if(c->time_valid) {
      int32_t signed_dt=(int32_t)(timestamp_ms-c->timestamp_ms);
      if(signed_dt<=0)return c->n_trk;
      dt=(unsigned int)signed_dt;
      if(dt>MOT_MAX_TIME_GAP_MS) {int next=c->next_id;mot_reset(c);c->next_id=next;dt=MOT_TIME_STEP_MS;}
   }
   c->time_valid=1;c->timestamp_ms=timestamp_ms;c->dt_ms=dt;c->timed_call=1;
   n=mot_step(c,w,cur,ai_p,ir_cnt);c->timed_call=0;return n;
}

#endif /* MOT_CORE_H */
