# Ti60F225：双网页、多目标跟踪与位置预测进度

本轮以 `8965c881218f5cfa5b3d24c0baf954a792d6dc32` 和已验证的 netfix04 网口修复为基线。工作在隔离副本 `D:\FPGA\motweb04`，未覆盖旧 netfix04、原 Efinity 工程或旧交付包。算法为自写 C，无引入外部开源项目。

## 使用入口

- PC 实时网页：http://169.254.47.62:8090/
- FPGA 板内网页：http://169.254.47.63/
- 本机离线算法回放：http://127.0.0.1:8092/

PC 与板端均使用 `tools/page.html`。网页显示大画面、全屏、当前捕捉人数、独立目标 ID、历史轨迹、速度、400 ms 预测落点及关注区预警。当前上限为 **2 个目标**。人数为本帧确认、尺寸达标的观测估计，遮挡续轨另列；累计 ID 不充当当前人数。

PC 从板内 HTTP 获取同一算法快照和匹配图片，串口/UDP 保留事件收集及回退用途。板端保留 8 个快照，PC 保留 8 张不可变图片；过期图片返回不存在，避免以新图冒充旧快照。两端的时间、像素和轨迹口径一致，但不同刷新时刻的帧号可以不同。

## 缩略图修复

旧代码对原始 uint8 灰度的 int8 位表示再次加 128，导致最高位翻转，部分亮像素变黑。新固件直接复制原始灰度，未用补点或滤波掩盖问题。PC 新固件配置是 `--udp-pixel-encoding uint8`；回退旧固件时才使用 `legacy-offset128`，不可对新固件重复修正。

1920×1080 全幅被采样为 96×96 数据后，网页按 16:9 恢复几何比例，支持大预览和全屏。传输仍是降采样灰度图，放大不会获得 HDMI 原始分辨率或彩色细节。其他裁切模式应使用其实际宽高比，不能一律拉伸。

## 算法改动与边界

修正框 IoU；两目标全局分配；独立相邻目标不因靠近而合并；遮挡速度从两次实际观测计算；不规则采样使用真实时间；统一关联、ETA 和 400 ms 外推的速度单位（Q4 像素/200 ms）；修正负向速度在 RV32 的符号提升；背景保留小数并抑制人体拖尾；16 位连通域标签避免第 256 个分量回绕；合并遮挡最多保留 4 秒并支持恢复原 ID。

当前是背景差分 + 全局 AI/红外支持的简易多目标跟踪，**不是逐人体神经网络检测器**。稳定 ID、人数及下一位置均为算法估计；未新增跌倒/姿态分类。预警标志不伪装为已执行的真实动作，实际唤醒证据仍以 `MMT_LP_EXIT reason=prewarn` 为准。

## 验证记录

- 19 项新增缺陷回归 + 20 项原回归通过。
- 13 项串口解析检查、9 项灰度/同步检查、14 项浏览器交互检查通过。
- 完整 HTML、JSON、PNG、TCP 丢包重传、FIN、跨连接隔离及双客户端快照保留检查通过。
- 实际 C 算法回放可显示两个目标并分别维护 ID；合成场景与实拍回放明确区分。
- 板端下载、CRC、HTTP 及浏览器验证，以 `evidence/mot_web_20261104/live_links_verified.json`、`ui_live_selftest.json`、`board_fw4-loader.log` 为最终依据；无这些 PASS 文件不视为交付完成。

受控合成场景中，交会观测匹配率由 61.36% 到 85.23%，ID 换号由 1 到 0，400 ms 预测平均误差由 3.2264 到 0.4110 网格像素。完整结果见 `metrics.json`，不能解释为真人准确率。

501 帧历史实拍均核验来源和像素，未使用旧脚本固定注入的 AI=90/IR=3。它们缺少人工人体框/身份真值，间隔中位数 1.66–3.26 秒，无法验证真实 400 ms 预测精度。按真实时间回放时，有确认观测的输出覆盖率为：场景 49.848%→30.091%，单人片段 48.101%→27.848%，双人片段 80.645%→66.667%。这是实际存在的回归信号，不能用 ID 数下降或合成改善掩盖；下一轮需要补充连续视频与人工标注再调参。**本轮没有完成现场多人走动或遮挡验收。**

## 运行与复现

```powershell
# 需要 Python 3；串口采集需要 pyserial。脚本隐藏运行窗口。
.\tools\start_network_monitor.ps1
.\tools\start_offline_replay.ps1

# PC / FPGA 共同网页：编辑后重新生成嵌入头文件，再编译固件。
py -3 .\tools\embed_page.py

# 本机 C 回归需要 Visual Studio 2022 C++ 工具。
.\evidence\mot_web_20261104\build_alg.bat
.\evidence\mot_web_20261104\build_alg_existing.bat
.\evidence\mot_web_20261104\build_native.bat
py -3 .\evidence\mot_web_20261104\build_replays.py
.\evidence\mot_web_20261104\build_http_test.bat
py -3 .\evidence\mot_web_20261104\test_net.py
py -3 .\evidence\mot_web_20261104\test_web_sync.py
py -3 .\evidence\mot_web_20261104\test_board_track_parser.py
py -3 .\evidence\mot_web_20261104\evaluate_recordings.py --saved-index .\evidence\mot_web_20261104\recordings_index_portable.json --recorded-time
```

离线回放只需包内的 PNG/JSON，不占用串口或板卡。随包录制原始像素和元数据可重跑评估；原始来源归档路径保留作追溯，接手者无需伪造缺失的 IR 或人工标签。

## 固件与回退

最终应用：`firmware/tinyml_pdti8.bin`（fw4），432522 字节，CRC32 `38DD7DBF`，SHA256 `3F570E52A9C035A9A8157EDCB9D0B4E3644D590BE46704AFF6F84AC909D968AF`。

网络位流沿用 netfix04_rxq2：SHA256 `865458AB2AF51C366AAA2C22DCFA3312F4AB104E90680185BC90F58BDF0E69F5`。本轮不修改 RTL、网卡地址或 SPI Flash，只做 JTAG 临时加载 + UART 应用载入。断电后不会保留此次 RAM 固件。

回退应用：`firmware/rollback_netfix04_fw6.bin`，CRC32 `129D6E09`，SHA256 `23574C8F2997CD86AA6291A30DB52F337C830981C7A92E01E7B45E4F5815E996`。回退时 PC 应配旧协议/灰度选项，旧程序和完整旧交付包仍保留在原位置。

软件构建入口 `evidence/v30_mot/build_v30.py`，官方工程树 `D:\v30_build\project`，GCC 15.2。本机下载工具为 Efinity 2026.1.132；本轮不是一次 Efinity 2025.1 RTL 重编译。继承的网络位流 setup 余量 −1.103 ns，仍未完成时序闭合，不以 HTTP 通信成功代替时序签核。

核心源码、构建日志、固件及两端验证记录均保存，未提交或推送 GitHub，也未覆盖原工程进度。
