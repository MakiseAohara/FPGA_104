`timescale 1ns/1ps
module tb_alarm_gate;
    reg alarm_raw=0, motion=0, ir_hot=0, ai_person=0;
    wire g_ai, g_or, g_ir;
    integer errors=0;
    v7_alarm_gate #(.IR_GATE_MODE(0)) u_ai (.alarm_raw(alarm_raw),.motion(motion),.ir_hot(ir_hot),.ai_person(ai_person),.alarm_gate(g_ai));
    v7_alarm_gate #(.IR_GATE_MODE(1)) u_or (.alarm_raw(alarm_raw),.motion(motion),.ir_hot(ir_hot),.ai_person(ai_person),.alarm_gate(g_or));
    v7_alarm_gate #(.IR_GATE_MODE(2)) u_ir (.alarm_raw(alarm_raw),.motion(motion),.ir_hot(ir_hot),.ai_person(ai_person),.alarm_gate(g_ir));
    task check; input e_ai,e_or,e_ir; input [255:0] name; begin #1;
        if (g_ai!==e_ai||g_or!==e_or||g_ir!==e_ir) begin errors=errors+1;
            $display("  FAIL %0s: ai=%b/%b or=%b/%b ir=%b/%b",name,g_ai,e_ai,g_or,e_or,g_ir,e_ir);
        end else $display("  PASS %0s: ai=%b or=%b ir=%b",name,g_ai,g_or,g_ir);
    end endtask
    initial begin
        $display("=== MERGE14 TB: alarm gate modes ===");
        // 验收用例：默认门控(0)，ir_hot=0，ai_person=1，motion=1 -> 拉起
        alarm_raw=1; motion=1; ir_hot=0; ai_person=1;
        check(1'b1,1'b1,1'b0,"acceptance: AI only path");
        // 红外单独不能拉起默认门控
        ir_hot=1; ai_person=0;
        check(1'b0,1'b1,1'b1,"IR alone: default off, mode1/2 on");
        // 无运动
        motion=0; ir_hot=0; ai_person=1;
        check(1'b0,1'b0,1'b0,"no motion blocks all");
        // alarm_raw=0
        motion=1; alarm_raw=0; ai_person=1;
        check(1'b0,1'b0,1'b0,"alarm_raw=0 blocks all");
        // 只有红外 + 默认门控
        alarm_raw=1; motion=1; ir_hot=1; ai_person=0;
        check(1'b0,1'b1,1'b1,"IR only with default gate");
        #10;
        if (errors==0) $display("=== RESULT: ALL TESTS PASSED ===");
        else $display("=== RESULT: TESTS FAILED (%0d) ===",errors);
        $finish;
    end
endmodule
