// MERGE10 testbench #2: APB register decode regression.
//  - dec_old : decode logic verbatim from MERGE8 ti60f225_oob_top.v (paddr[5:2], regs 0..10)
//  - dec_new : same logic from MERGE10 ti60f225_oob_top.v (paddr[6:2], regs 0..10 unchanged,
//              plus reg16/17/18 for I2C CMD/STATUS/RDATA)
// Checks: regs 0..10 (at least reg8/reg9/reg10) behave identically old vs new;
//         new regs 16/17/18 behave as specified (cmd ignored when busy/not-ready,
//         done sticky/clear-on-read, rdata readback).
`timescale 1ns/1ps

// ---------------------------------------------------------------------------
// OLD decode: copied verbatim from D:\v7work\v7_MERGE8\rtl\ti60f225_oob_top.v
// ---------------------------------------------------------------------------
module dec_old (
    input  wire        core_clk,
    input  wire        w_arstn,
    input  wire        soc_apb_psel,
    input  wire        soc_apb_penable,
    input  wire        soc_apb_pwrite,
    input  wire [31:0] soc_apb_paddr,
    input  wire [31:0] soc_apb_pwdata,
    input  wire        cal_done,
    input  wire [31:0] soc_aw_cnt,
    input  wire [31:0] soc_ar_cnt,
    input  wire [31:0] bridge_state,
    input  wire [31:0] t_aw_cnt,
    input  wire [31:0] t_ar_cnt,
    input  wire [31:0] ci_cnt,
    input  wire [31:0] irq_cnt,
    input  wire        soc_system_reset,
    output reg  [31:0] soc_apb_prdata,
    output reg         osd_alarm_core,
    output reg  [8:0]  ai_score_core
);
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) osd_alarm_core <= 1'b0;
  else if(soc_apb_psel && soc_apb_penable && soc_apb_pwrite &&
          soc_apb_paddr[5:2]==4'd9)
    osd_alarm_core <= soc_apb_pwdata[0];
end
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) ai_score_core <= 9'd0;
  else if(soc_apb_psel && soc_apb_penable && soc_apb_pwrite &&
          soc_apb_paddr[5:2]==4'd10)
    ai_score_core <= soc_apb_pwdata[8:0];
end
always @* begin
  case(soc_apb_paddr[5:2])
    4'd0: soc_apb_prdata = {31'd0, cal_done};
    4'd1: soc_apb_prdata = soc_aw_cnt;
    4'd2: soc_apb_prdata = soc_ar_cnt;
    4'd3: soc_apb_prdata = {29'd0, bridge_state};
    4'd4: soc_apb_prdata = t_aw_cnt;
    4'd5: soc_apb_prdata = t_ar_cnt;
    4'd6: soc_apb_prdata = ci_cnt;
    4'd7: soc_apb_prdata = irq_cnt;
    4'd8: soc_apb_prdata = {31'd0, soc_system_reset};
    4'd9: soc_apb_prdata = {31'd0, osd_alarm_core};
    4'd10: soc_apb_prdata = {23'd0, ai_score_core};
    default: soc_apb_prdata = 32'd0;
  endcase
end
endmodule

// ---------------------------------------------------------------------------
// NEW decode: copied verbatim from D:\v7work\v7_MERGE10\rtl\ti60f225_oob_top.v
// ---------------------------------------------------------------------------
module dec_new (
    input  wire        core_clk,
    input  wire        w_arstn,
    input  wire        soc_apb_psel,
    input  wire        soc_apb_penable,
    input  wire        soc_apb_pwrite,
    input  wire [31:0] soc_apb_paddr,
    input  wire [31:0] soc_apb_pwdata,
    input  wire        cal_done,
    input  wire [31:0] soc_aw_cnt,
    input  wire [31:0] soc_ar_cnt,
    input  wire [31:0] bridge_state,
    input  wire [31:0] t_aw_cnt,
    input  wire [31:0] t_ar_cnt,
    input  wire [31:0] ci_cnt,
    input  wire [31:0] irq_cnt,
    input  wire        soc_system_reset,
    // I2C side (CLK_5M domain signals, modeled directly here)
    input  wire        i2c_busy_5m,
    input  wire        i2c_done_toggle_5m,
    input  wire        i2c_ready_5m,
    input  wire [7:0]  i2c_rdata_5m,
    output reg  [31:0] soc_apb_prdata,
    output reg         osd_alarm_core,
    output reg  [8:0]  ai_score_core,
    output reg         i2c_req_toggle,
    output reg         i2c_rw_cmd,
    output reg  [15:0] i2c_addr_cmd,
    output reg  [7:0]  i2c_wdata_cmd
);
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) osd_alarm_core <= 1'b0;
  else if(soc_apb_psel && soc_apb_penable && soc_apb_pwrite &&
          soc_apb_paddr[6:2]==5'd9)
    osd_alarm_core <= soc_apb_pwdata[0];
end
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) ai_score_core <= 9'd0;
  else if(soc_apb_psel && soc_apb_penable && soc_apb_pwrite &&
          soc_apb_paddr[6:2]==5'd10)
    ai_score_core <= soc_apb_pwdata[8:0];
end
// ---- MERGE10 APB -> camera SCCB block (verbatim logic) ----
wire        i2c_busy_5m_w = i2c_busy_5m;
wire        i2c_done_toggle_5m_w = i2c_done_toggle_5m;
wire        i2c_ready_5m_w = i2c_ready_5m;
wire [7:0]  i2c_rdata_5m_w = i2c_rdata_5m;
wire i2c_cmd_wr    = soc_apb_psel && soc_apb_penable && soc_apb_pwrite &&
                     (soc_apb_paddr[6:2] == 5'd16);
wire i2c_status_rd = soc_apb_psel && soc_apb_penable && !soc_apb_pwrite &&
                     (soc_apb_paddr[6:2] == 5'd17);
reg [1:0] i2c_busy_sync;
reg [1:0] i2c_ready_sync;
reg [1:0] i2c_done_sync;
reg [7:0] i2c_rdata_s1, i2c_rdata_s2;
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) begin
    i2c_busy_sync  <= 2'd0;
    i2c_ready_sync <= 2'd0;
    i2c_done_sync  <= 2'd0;
    i2c_rdata_s1   <= 8'd0;
    i2c_rdata_s2   <= 8'd0;
  end else begin
    i2c_busy_sync  <= {i2c_busy_sync[0],  i2c_busy_5m_w};
    i2c_ready_sync <= {i2c_ready_sync[0], i2c_ready_5m_w};
    i2c_done_sync  <= {i2c_done_sync[0],  i2c_done_toggle_5m_w};
    i2c_rdata_s1   <= i2c_rdata_5m_w;
    i2c_rdata_s2   <= i2c_rdata_s1;
  end
end
wire i2c_busy_core  = i2c_busy_sync[1];
wire i2c_ready_core = i2c_ready_sync[1];
wire i2c_done_edge  = i2c_done_sync[1] ^ i2c_done_sync[0];
wire [7:0] i2c_rdata_core = i2c_rdata_s2;
reg i2c_done_sticky;
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) i2c_done_sticky <= 1'b0;
  else if(i2c_done_edge) i2c_done_sticky <= 1'b1;
  else if(i2c_status_rd) i2c_done_sticky <= 1'b0;
end
always @(posedge core_clk or negedge w_arstn) begin
  if(!w_arstn) begin
    i2c_req_toggle <= 1'b0;
    i2c_rw_cmd     <= 1'b0;
    i2c_addr_cmd   <= 16'd0;
    i2c_wdata_cmd  <= 8'd0;
  end else if(i2c_cmd_wr && soc_apb_pwdata[31] &&
              !i2c_busy_core && i2c_ready_core) begin
    i2c_rw_cmd     <= soc_apb_pwdata[30];
    i2c_addr_cmd   <= soc_apb_pwdata[23:8];
    i2c_wdata_cmd  <= soc_apb_pwdata[7:0];
    i2c_req_toggle <= ~i2c_req_toggle;
  end
end
always @* begin
  case(soc_apb_paddr[6:2])
    5'd0: soc_apb_prdata = {31'd0, cal_done};
    5'd1: soc_apb_prdata = soc_aw_cnt;
    5'd2: soc_apb_prdata = soc_ar_cnt;
    5'd3: soc_apb_prdata = {29'd0, bridge_state};
    5'd4: soc_apb_prdata = t_aw_cnt;
    5'd5: soc_apb_prdata = t_ar_cnt;
    5'd6: soc_apb_prdata = ci_cnt;
    5'd7: soc_apb_prdata = irq_cnt;
    5'd8: soc_apb_prdata = {31'd0, soc_system_reset};
    5'd9: soc_apb_prdata = {31'd0, osd_alarm_core};
    5'd10: soc_apb_prdata = {23'd0, ai_score_core};
    5'd16: soc_apb_prdata = 32'd0;
    5'd17: soc_apb_prdata = {29'd0, i2c_ready_core, i2c_done_sticky, i2c_busy_core};
    5'd18: soc_apb_prdata = {24'd0, i2c_rdata_core};
    default: soc_apb_prdata = 32'd0;
  endcase
end
endmodule

// ---------------------------------------------------------------------------
module tb_apb_regs;
reg clk = 0;
always #100 clk = ~clk;          // 5 MHz
reg rst_n = 0;
wire w_arstn = rst_n;

reg        psel = 0, penable = 0, pwrite = 0;
reg [31:0] paddr = 0, pwdata = 0;

// shared "counter" stimuli
reg        cal_done = 1'b1;
reg [31:0] soc_aw_cnt = 32'h11, soc_ar_cnt = 32'h22, bridge_state = 32'd3;
reg [31:0] t_aw_cnt = 32'h44, t_ar_cnt = 32'h55, ci_cnt = 32'h66, irq_cnt = 32'h77;
reg        soc_system_reset = 1'b1;

wire [31:0] prdata_old, prdata_new;
wire        osd_old, osd_new;
wire [8:0]  ai_old, ai_new;

dec_old u_old (
  .core_clk(clk), .w_arstn(w_arstn),
  .soc_apb_psel(psel), .soc_apb_penable(penable), .soc_apb_pwrite(pwrite),
  .soc_apb_paddr(paddr), .soc_apb_pwdata(pwdata),
  .cal_done(cal_done), .soc_aw_cnt(soc_aw_cnt), .soc_ar_cnt(soc_ar_cnt),
  .bridge_state(bridge_state), .t_aw_cnt(t_aw_cnt), .t_ar_cnt(t_ar_cnt),
  .ci_cnt(ci_cnt), .irq_cnt(irq_cnt), .soc_system_reset(soc_system_reset),
  .soc_apb_prdata(prdata_old), .osd_alarm_core(osd_old), .ai_score_core(ai_old)
);

reg        i2c_busy_5m = 0, i2c_done_toggle_5m = 0, i2c_ready_5m = 1;
reg [7:0]  i2c_rdata_5m = 8'h00;
wire       i2c_req_toggle, i2c_rw_cmd;
wire [15:0] i2c_addr_cmd;
wire [7:0]  i2c_wdata_cmd;

dec_new u_new (
  .core_clk(clk), .w_arstn(w_arstn),
  .soc_apb_psel(psel), .soc_apb_penable(penable), .soc_apb_pwrite(pwrite),
  .soc_apb_paddr(paddr), .soc_apb_pwdata(pwdata),
  .cal_done(cal_done), .soc_aw_cnt(soc_aw_cnt), .soc_ar_cnt(soc_ar_cnt),
  .bridge_state(bridge_state), .t_aw_cnt(t_aw_cnt), .t_ar_cnt(t_ar_cnt),
  .ci_cnt(ci_cnt), .irq_cnt(irq_cnt), .soc_system_reset(soc_system_reset),
  .i2c_busy_5m(i2c_busy_5m), .i2c_done_toggle_5m(i2c_done_toggle_5m),
  .i2c_ready_5m(i2c_ready_5m), .i2c_rdata_5m(i2c_rdata_5m),
  .soc_apb_prdata(prdata_new), .osd_alarm_core(osd_new), .ai_score_core(ai_new),
  .i2c_req_toggle(i2c_req_toggle), .i2c_rw_cmd(i2c_rw_cmd),
  .i2c_addr_cmd(i2c_addr_cmd), .i2c_wdata_cmd(i2c_wdata_cmd)
);

integer errors = 0;
task fail;
  input [1023:0] msg;
  begin errors = errors + 1; $display("  FAIL: %0s (t=%0t)", msg, $time); end
endtask

task apb_write;
  input [31:0] addr;
  input [31:0] data;
  begin
    @(posedge clk); #10;
    psel = 1; pwrite = 1; paddr = addr; pwdata = data;
    @(posedge clk); #10;
    penable = 1;
    @(posedge clk); #10;
    psel = 0; penable = 0; pwrite = 0;
    #40;
  end
endtask

task apb_read;
  input  [31:0] addr;
  output [31:0] old_d, new_d;
  begin
    @(posedge clk); #10;
    psel = 1; pwrite = 0; paddr = addr; pwdata = 32'h0;
    @(posedge clk); #10;
    penable = 1;
    #60;
    old_d = prdata_old; new_d = prdata_new;
    @(posedge clk); #10;
    psel = 0; penable = 0;
    #40;
  end
endtask

reg [31:0] old_d, new_d;
integer i;
integer req_toggles;

initial begin
  $display("=== MERGE10 TB2: APB regs 0-10 regression + new regs 16/17/18 ===");
  rst_n = 0;
  repeat (20) @(posedge clk);
  rst_n = 1;
  repeat (10) @(posedge clk);

  // ---- 1) read regs 0..10: old vs new must match ----
  for (i = 0; i <= 10; i = i + 1) begin
    apb_read(i*4, old_d, new_d);
    if (old_d !== new_d) fail("read reg decode mismatch");
    else $display("  PASS read reg%0d (0x%02x): old=0x%08x == new=0x%08x", i, i*4, old_d, new_d);
  end

  // ---- 2) write reg8/9/10: captured outputs must match ----
  apb_write(32'h08*4/4*0 + 32'h20, 32'h00000000); // reg8: soc_system_reset source is external -> just compare readback
  apb_read(32'h08*4/4*0 + 32'h20, old_d, new_d);
  if (old_d !== new_d) fail("reg8 readback mismatch");
  else $display("  PASS reg8 readback old/new = 0x%08x", old_d);

  apb_write(32'h24, 32'h1);          // reg9 = OSD alarm
  @(posedge clk);
  if (osd_old !== osd_new) fail("reg9 write: osd_alarm old/new mismatch");
  else if (osd_new !== 1'b1) fail("reg9 write: osd_alarm not updated");
  else $display("  PASS reg9 write: osd_alarm old=new=1");
  apb_read(32'h24, old_d, new_d);
  if (old_d !== new_d) fail("reg9 readback mismatch");
  else $display("  PASS reg9 readback old/new = 0x%08x", old_d);

  apb_write(32'h28, 32'h1A5);        // reg10 = AI raw score
  @(posedge clk);
  if (ai_old !== ai_new) fail("reg10 write: ai_score old/new mismatch");
  else if (ai_new !== 9'h1A5) fail("reg10 write: ai_score not updated");
  else $display("  PASS reg10 write: ai_score old=new=0x%03x", ai_new);
  apb_read(32'h28, old_d, new_d);
  if (old_d !== new_d) fail("reg10 readback mismatch");
  else $display("  PASS reg10 readback old/new = 0x%08x", old_d);

  // reg8 (0x20) is read-only source (soc_system_reset external); both must ignore writes
  apb_write(32'h20, 32'hFFFFFFFF);
  apb_read(32'h20, old_d, new_d);
  if (old_d !== new_d) fail("reg8 post-write mismatch");
  else $display("  PASS reg8 unaffected by write (external signal), old=new=0x%08x", old_d);

  // ---- 3) new regs 16/17/18 ----
  // 3a) CMD ignored while ready=0
  i2c_ready_5m = 0; repeat (5) @(posedge clk);
  req_toggles = 0;
  apb_write(32'h40, {1'b1, 1'b0, 6'd0, 16'h3e00, 8'h5a});
  repeat (5) @(posedge clk);
  if (i2c_req_toggle !== 1'b0) fail("reg16: CMD accepted while ready=0");
  else $display("  PASS reg16: CMD ignored while ready=0");
  i2c_ready_5m = 1; repeat (5) @(posedge clk);

  // 3b) CMD ignored while busy=1
  i2c_busy_5m = 1; repeat (5) @(posedge clk);
  apb_write(32'h40, {1'b1, 1'b0, 6'd0, 16'h3e01, 8'h5b});
  repeat (5) @(posedge clk);
  if (i2c_req_toggle !== 1'b0) fail("reg16: CMD accepted while busy=1");
  else $display("  PASS reg16: CMD ignored while busy=1");
  i2c_busy_5m = 0; repeat (5) @(posedge clk);

  // 3c) CMD accepted when ready=1 & !busy
  apb_write(32'h40, {1'b1, 1'b1, 6'd0, 16'h3e00, 8'h5a});  // rw=1, addr=0x3e00, data=0x5a
  repeat (5) @(posedge clk);
  if (i2c_req_toggle !== 1'b1) fail("reg16: CMD not accepted");
  else $display("  PASS reg16: CMD accepted (toggle=1, rw=%0b addr=0x%04x data=0x%02x)",
                i2c_rw_cmd, i2c_addr_cmd, i2c_wdata_cmd);
  if (i2c_rw_cmd !== 1'b1)        fail("reg16: rw bit mismatch");
  if (i2c_addr_cmd !== 16'h3e00)  fail("reg16: addr mismatch");
  if (i2c_wdata_cmd !== 8'h5a)    fail("reg16: wdata mismatch");

  // 3d) status: busy=1, ready=1 -> bit0=1, bit2=1
  i2c_busy_5m = 1; repeat (5) @(posedge clk);
  apb_read(32'h44, old_d, new_d);
  if (new_d[0] !== 1'b1) fail("reg17: busy bit != 1");
  if (new_d[2] !== 1'b1) fail("reg17: ready bit != 1");
  else $display("  PASS reg17 status while busy: busy=%0b done=%0b ready=%0b", new_d[0], new_d[1], new_d[2]);
  i2c_busy_5m = 0; repeat (5) @(posedge clk);

  // 3e) done sticky: toggle i2c_done_toggle_5m -> bit1 set; read clears it
  i2c_done_toggle_5m = 1; repeat (5) @(posedge clk);
  apb_read(32'h44, old_d, new_d);
  if (new_d[1] !== 1'b1) fail("reg17: done sticky not set");
  else $display("  PASS reg17: done sticky set after done_toggle");
  apb_read(32'h44, old_d, new_d);
  if (new_d[1] !== 1'b0) fail("reg17: done sticky not cleared by read");
  else $display("  PASS reg17: done sticky cleared by read");

  // 3f) rdata
  i2c_rdata_5m = 8'hA7; repeat (5) @(posedge clk);
  apb_read(32'h48, old_d, new_d);
  if (new_d[7:0] !== 8'hA7) fail("reg18: rdata mismatch");
  else $display("  PASS reg18: rdata readback = 0x%02x", new_d[7:0]);

  // 3g) 0x40/0x44/0x48: old decode (4-bit alias) and new decode differ by design;
  //     report both, no pass/fail (old design had no such registers).
  apb_read(32'h40, old_d, new_d);
  $display("  INFO 0x40: old(alias)=0x%08x new(CMD readback)=0x%08x", old_d, new_d);
  apb_read(32'h44, old_d, new_d);
  $display("  INFO 0x44: old(alias)=0x%08x new(STATUS)=0x%08x", old_d, new_d);
  apb_read(32'h48, old_d, new_d);
  $display("  INFO 0x48: old(alias)=0x%08x new(RDATA)=0x%08x", old_d, new_d);

  repeat (20) @(posedge clk);
  if (errors == 0) $display("=== RESULT: ALL TESTS PASSED ===");
  else             $display("=== RESULT: TESTS FAILED, errors=%0d ===", errors);
  $finish;
end

initial begin
  #2_000_000;
  $display("=== RESULT: GLOBAL TIMEOUT ===");
  $finish;
end
endmodule
