`timescale 1ns / 1ps
//==========================================================================
// v7_alarm_gate.v — MERGE13: 报警门控（单独成模块，便于仿真）
//   alarm_gate = alarm_raw & motion & (REQUIRE_IR ? (ir_hot | ai_person) : 1)
//   MERGE13 改动：红外热点或 AI 人体判决任一成立即可（原来只认 ir_hot）
//==========================================================================
module v7_alarm_gate #(
    parameter REQUIRE_IR = 1
)(
    input  wire alarm_raw,    // 融合得分 >= 阈值 且处于非授权窗口
    input  wire motion,       // 帧差运动
    input  wire ir_hot,       // 红外热点（hot_delta >= HOT_ON）
    input  wire ai_person,    // AI 人体判决（v7_mmt_core 内为 ai_p_eff）
    output wire alarm_gate
);
    wire ir_path = (REQUIRE_IR == 0) ? 1'b1 : (ir_hot | ai_person);
    assign alarm_gate = alarm_raw & motion & ir_path;
endmodule
