// MERGE11 testbench: APB words 11..15 (RISC-V decision ② / low-power status ⑤)
//  - a. words 11/12/13 read back the video-domain evidence after a vs snapshot
//  - b. words 14/15 write -> video-domain control bits; alarm selection truth table
//  - c. reset default: fw_decision_enable=0 -> alarm_final == rtl_alarm (MERGE10 behaviour)
`timescale 1ns/1ps

module tb_apb_ext;

// ---------------- clocks / resets ----------------
reg core_clk = 0, vid_clk = 0;
always #5    core_clk = ~core_clk;     // 100 MHz
always #3.367 vid_clk  = ~vid_clk;     // ~148.5 MHz
reg core_rst_n = 0, vid_rst_n = 0;

// ---------------- APB master ----------------
reg        psel = 0, penable = 0, pwrite = 0;
reg [31:0] paddr = 0, pwdata = 0;
wire [31:0] prdata;
wire        hit;

// ---------------- video-domain evidence ----------------
reg        vs_rise = 0;
reg [31:0] evt_v = 0, env_v = 0, st_v = 0;
wire       fw_decision_enable_v, fw_alarm_req_v;
wire       fw_decision_enable, fw_alarm_req;

v7_apb_ext u_dut (
    .core_clk(core_clk), .core_rst_n(core_rst_n),
    .paddr(paddr), .pwdata(pwdata),
    .psel(psel), .penable(penable), .pwrite(pwrite),
    .prdata(prdata), .hit(hit),
    .vid_clk(vid_clk), .vid_rst_n(vid_rst_n),
    .vs_rise(vs_rise),
    .evt_v(evt_v), .env_v(env_v), .st_v(st_v),
    .fw_decision_enable_v(fw_decision_enable_v),
    .fw_alarm_req_v(fw_alarm_req_v),
    .fw_decision_enable(fw_decision_enable),
    .fw_alarm_req(fw_alarm_req)
);

// ---------------- alarm selection ----------------
reg  rtl_alarm = 0;
wire alarm_final;
v7_alarm_sel u_alsel (
    .rtl_alarm(rtl_alarm),
    .fw_decision_enable(fw_decision_enable_v),
    .fw_alarm_req(fw_alarm_req_v),
    .alarm_final(alarm_final)
);

// ---------------- helpers ----------------
integer errors = 0;

task fail;
    input [255:0] msg;
    begin
        errors = errors + 1;
        $display("  FAIL: %0s (t=%0t)", msg, $time);
    end
endtask

task apb_write;
    input [31:0] a;
    input [31:0] d;
    begin
        @(posedge core_clk); #1;
        psel = 1; pwrite = 1; paddr = a; pwdata = d;
        @(posedge core_clk); #1;
        penable = 1;
        @(posedge core_clk); #1;
        psel = 0; penable = 0; pwrite = 0;
        #10;
    end
endtask

task apb_read;
    input  [31:0] a;
    output [31:0] d;
    begin
        psel = 1; pwrite = 0; paddr = a; pwdata = 0;
        #2;
        d = prdata;
        #6;
        psel = 0;
        #10;
    end
endtask

task vs_pulse;
    begin
        @(posedge vid_clk); #1;
        vs_rise = 1;
        @(posedge vid_clk); #1;
        vs_rise = 0;
    end
endtask

// wait N video clocks (for 2FF CDC)
task wait_vid;
    input integer n;
    integer i;
    begin
        for (i = 0; i < n; i = i + 1) @(posedge vid_clk);
    end
endtask

// wait N core clocks (for toggle handshake capture)
task wait_core;
    input integer n;
    integer i;
    begin
        for (i = 0; i < n; i = i + 1) @(posedge core_clk);
    end
endtask

// ---------------- expected values ----------------
reg [31:0] evt_exp, env_exp, st_exp, st_exp_cfg;
reg [31:0] rd;
integer i;

initial begin
    // evidence pattern:
    //  word11: [31:16]=0x0150 area, [15:4]=0x1C2 (450 = 45.0C), [3:0]=1010
    evt_exp = {16'h0150, 12'h1C2, 4'b1010};
    //  word12: [31:16]=0x01F4 (500 = 50.0%RH), [15:0]=0x00F0 (240 = 24.0C)
    env_exp = {16'h01F4, 16'h00F0};
    //  word13: [31:24]=0x5A vs_cnt, [18]=1 alarm, [17]=1 low_pwr, [16:9]=77, [8:0]=321
    st_exp  = {8'h5A, 3'b000, 2'b00, 1'b1, 1'b1, 8'd77, 9'd321};
    // after word15 = 0x3: readback bits [19]=fw_decision_enable [20]=fw_ai_infer_en
    st_exp_cfg = st_exp | (32'h1 << 19) | (32'h1 << 20);

    $display("=== MERGE11 TB: APB words 11..15 (decision + low-power) ===");
    core_rst_n = 0; vid_rst_n = 0;
    repeat (10) @(posedge core_clk);
    repeat (10) @(posedge vid_clk);
    core_rst_n = 1; vid_rst_n = 1;
    repeat (5) @(posedge core_clk);
    repeat (5) @(posedge vid_clk);

    // ------------------------------------------------------------------
    // c-1) reset default: fw_decision_enable = 0 -> alarm_final == rtl_alarm
    // ------------------------------------------------------------------
    rtl_alarm = 0; #40;
    if (alarm_final !== 1'b0) fail("reset: alarm_final != 0 when rtl_alarm=0");
    rtl_alarm = 1; #40;
    if (alarm_final !== 1'b1) fail("reset: alarm_final != rtl_alarm when fw_decision_enable=0");
    if (fw_decision_enable !== 1'b0) fail("reset: fw_decision_enable readback != 0");
    $display("  PASS (c1) default fw_decision_enable=0: alarm_final follows rtl_alarm");

    // ------------------------------------------------------------------
    // a) evidence snapshot -> words 11/12/13
    // ------------------------------------------------------------------
    evt_v = evt_exp; env_v = env_exp; st_v = st_exp;
    vs_pulse;                       // one frame: snapshot + toggle
    wait_core(8);                   // core side latches on toggle edge
    apb_read(32'h2C, rd);           // word11
    if (rd !== evt_exp) begin
        fail("word11 readback mismatch"); $display("    got=%08x exp=%08x", rd, evt_exp);
    end else $display("  PASS (a1) word11 = %08x (motion/IR evidence)", rd);
    apb_read(32'h30, rd);           // word12
    if (rd !== env_exp) begin
        fail("word12 readback mismatch"); $display("    got=%08x exp=%08x", rd, env_exp);
    end else $display("  PASS (a2) word12 = %08x (environment)", rd);
    apb_read(32'h34, rd);           // word13
    if (rd !== st_exp) begin
        fail("word13 readback mismatch"); $display("    got=%08x exp=%08x", rd, st_exp);
    end else $display("  PASS (a3) word13 = %08x (fusion/low-power/alarm)", rd);
    if (hit !== 1'b1) fail("hit not asserted for word11..13");

    // evidence changes only on next vs snapshot
    evt_v = {16'h0001, 12'h001, 4'b0001};
    wait_core(4);
    apb_read(32'h2C, rd);
    if (rd !== evt_exp) fail("word11 changed without vs snapshot");
    else $display("  PASS (a4) word11 stable until next vs snapshot");
    vs_pulse; wait_core(8);
    apb_read(32'h2C, rd);
    if (rd !== {16'h0001, 12'h001, 4'b0001}) fail("word11 not updated after second vs");
    else $display("  PASS (a5) word11 updated on next vs snapshot");

    // ------------------------------------------------------------------
    // b) words 14/15 writes -> video domain + readback
    // ------------------------------------------------------------------
    apb_write(32'h38, 32'h0000_5A01);   // word14: [0]=1 alarm_req, [15:8]=0x5A conf
    apb_write(32'h3C, 32'h0000_0003);   // word15: [0]=fw_decision_enable, [1]=ai_infer_en
    wait_vid(6);
    if (fw_decision_enable_v !== 1'b1) fail("word15 bit0 did not reach video domain");
    else $display("  PASS (b1) fw_decision_enable_v = 1 after word15 write");
    if (fw_alarm_req_v !== 1'b1) fail("word14 bit0 did not reach video domain");
    else $display("  PASS (b2) fw_alarm_req_v = 1 after word14 write");
    apb_read(32'h34, rd);               // word13 readback bits
    if (rd !== st_exp_cfg) begin
        fail("word13 readback bits [19]/[20] mismatch");
        $display("    got=%08x exp=%08x", rd, st_exp_cfg);
    end else $display("  PASS (b3) word13 readback = %08x (fw_en/ai_en visible)", rd);

    // b4) selection truth table with fw_decision_enable = 1
    rtl_alarm = 0; #40;
    if (alarm_final !== 1'b0) fail("enable=1 req=1 rtl=0: alarm_final != 0");
    rtl_alarm = 1; #40;
    if (alarm_final !== 1'b1) fail("enable=1 req=1 rtl=1: alarm_final != 1");
    apb_write(32'h38, 32'h0000_0000);   // word14: alarm_req = 0
    wait_vid(6);
    if (alarm_final !== 1'b0) fail("enable=1 req=0 rtl=1: alarm_final should be suppressed");
    else $display("  PASS (b4) enable=1, req=0 -> rtl alarm suppressed (firmware veto)");
    apb_write(32'h38, 32'h0000_5A01);   // restore req
    wait_vid(6);
    if (alarm_final !== 1'b1) fail("enable=1 req=1 rtl=1: alarm_final should be 1");

    // b5) disable -> back to MERGE10 behaviour
    apb_write(32'h3C, 32'h0000_0000);   // fw_decision_enable = 0
    wait_vid(6);
    if (fw_decision_enable_v !== 1'b0) fail("word15 clear did not reach video domain");
    rtl_alarm = 1; #40;
    if (alarm_final !== 1'b1) fail("enable=0: alarm_final != rtl_alarm after disabling");
    else $display("  PASS (b5) enable=0 -> alarm_final follows rtl_alarm (MERGE10 behaviour)");

    // ------------------------------------------------------------------
    // alarm truth table (all 8 combinations)
    // ------------------------------------------------------------------
    for (i = 0; i < 8; i = i + 1) begin
        rtl_alarm = (i >> 2) & 1;
        // drive apb word15/14 directly, then wait
        apb_write(32'h3C, (i & 1) ? 32'h1 : 32'h0);
        apb_write(32'h38, (i & 2) ? 32'h1 : 32'h0);
        wait_vid(6);
        if (alarm_final !== ((i & 1) ? (rtl_alarm & ((i >> 1) & 1)) : rtl_alarm))
            fail("alarm truth table mismatch");
    end
    $display("  PASS (b6) alarm selection truth table: enable=0 -> rtl_alarm; enable=1 -> rtl_alarm & fw_req");

    repeat (10) @(posedge core_clk);
    if (errors == 0) $display("=== RESULT: ALL TESTS PASSED ===");
    else             $display("=== RESULT: TESTS FAILED, errors=%0d ===", errors);
    $finish;
end

initial begin
    #2_000_000;
    $display("=== RESULT: GLOBAL TIMEOUT ===");
    $finish;
end

endmodule
