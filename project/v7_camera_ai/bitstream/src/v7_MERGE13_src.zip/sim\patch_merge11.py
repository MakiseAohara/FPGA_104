﻿import io, sys
M = r"D:\v7work\v7_MERGE11"
top_path = M + r"\rtl\ti60f225_oob_top.v"
xml_path = M + r"\ti60f225_oob.xml"

def rd(p):
    return open(p, "rb").read()

def wr(p, b):
    open(p, "wb").write(b)

def rep(t, old, new, tag):
    n = t.count(old)
    if n != 1:
        raise SystemExit("PATTERN %s: %d matches (need 1)" % (tag, n))
    return t.replace(old, new, 1)

top = rd(top_path)
orig_len = len(top)

# ---- 1) read mux: words 11/12/13 ----
old = b"    5'd10: soc_apb_prdata = {23'd0, ai_score_core};\n    5'd16: soc_apb_prdata = 32'd0;"
new = (b"    5'd10: soc_apb_prdata = {23'd0, ai_score_core};\n"
       b"    5'd11: soc_apb_prdata = apb_ext_prdata;   // MERGE11: word11 motion/IR evidence\n"
       b"    5'd12: soc_apb_prdata = apb_ext_prdata;   // MERGE11: word12 environment\n"
       b"    5'd13: soc_apb_prdata = apb_ext_prdata;   // MERGE11: word13 fusion/low-power/alarm status\n"
       b"    5'd16: soc_apb_prdata = 32'd0;")
top = rep(top, old, new, "read-mux")

# ---- 2) core instance: add fw control inputs ----
old = b"\t.ai_person(osd_alarm_v2), .ai_score(ai_score_v2[7:0]), .ai_alive(ai_score_v2[8]), .key_night_n(key_night_n), .key_learn_n(key_learn_n),\n"
new = (old +
       b"\t.fw_decision_enable(fw_decision_enable_v), .fw_alarm_req(fw_alarm_req_v),\n")
top = rep(top, old, new, "core-fw-inputs")

# ---- 3) core instance: add obs outputs ----
old = b"\t.buzzer(sns_buzzer), .led(mmt_led), .alarm_active(mmt_alarm_active),\n"
new = (old +
       b"\t.obs_evt(obs_evt_v), .obs_env(obs_env_v), .obs_st(obs_st_v),\n")
top = rep(top, old, new, "core-obs-outputs")

# ---- 4) insert v7_apb_ext instance + vs_rise before v7_mmt_core ----
anchor = b"v7_mmt_core #(.AI_MODE(1)) u_v7_mmt ("
block = b"""// ========================================================================
// MERGE11: APB words 11..15 -- RISC-V decision (item 2) + low-power status (item 5)
//   word11/12/13 read-only evidence; word14/15 write firmware decision/control
//   CDC: evidence video->core (per-frame toggle handshake), controls core->video (2 FF)
// ========================================================================
reg vs_d_v;
always @(posedge hdmi_tx_slow_clk or negedge vid_rst_n) begin
  if(!vid_rst_n) vs_d_v <= 1'b0;
  else           vs_d_v <= enc_vs_in;
end
wire vs_rise_v = enc_vs_in & ~vs_d_v;

wire [31:0] obs_evt_v, obs_env_v, obs_st_v;
wire        apb_ext_hit;
wire [31:0] apb_ext_prdata;
wire        fw_decision_enable_v, fw_alarm_req_v;
v7_apb_ext u_apb_ext (
  .core_clk(core_clk), .core_rst_n(w_arstn),
  .paddr(soc_apb_paddr), .pwdata(soc_apb_pwdata),
  .psel(soc_apb_psel), .penable(soc_apb_penable), .pwrite(soc_apb_pwrite),
  .prdata(apb_ext_prdata), .hit(apb_ext_hit),
  .vid_clk(hdmi_tx_slow_clk), .vid_rst_n(vid_rst_n),
  .vs_rise(vs_rise_v),
  .evt_v(obs_evt_v), .env_v(obs_env_v), .st_v(obs_st_v),
  .fw_decision_enable_v(fw_decision_enable_v), .fw_alarm_req_v(fw_alarm_req_v),
  .fw_decision_enable(), .fw_alarm_req()
);

"""
top = rep(top, anchor, block + anchor, "apb-ext-instance")
wr(top_path, top)
print("top.v: %d -> %d bytes (+%d)" % (orig_len, len(top), len(top)-orig_len))
non_ascii = sum(1 for b in top if b > 127)
print("top.v non-ascii bytes:", non_ascii)

# ---- 5) XML: add two design_file lines after v7_i2c_probe.v ----
xml = rd(xml_path)
ox = len(xml)
old = b'<efx:design_file name="rtl/v7/mmt/v7_i2c_probe.v" version="default" library="default"/>\n'
new = (old +
       b'<efx:design_file name="rtl/v7/mmt/v7_apb_ext.v" version="default" library="default"/>\n'
       b'<efx:design_file name="rtl/v7/mmt/v7_alarm_sel.v" version="default" library="default"/>\n')
xml = rep(xml, old, new, "xml-design-files")
wr(xml_path, xml)
print("xml: %d -> %d bytes (+%d)" % (ox, len(xml), len(xml)-ox))
