// MERGE13 新增仿真：OSD 的 EVT 文本必须来自 word14 的 evt_code（1=INTRUDE 2=TREND 3=PERSON 4=LOWPWR 其它=NORMAL）
`timescale 1ns/1ps
module tb_evt_osd;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0;
    reg refresh=0;
    reg [15:0] temp_x100=2500, rh_x100=5000, ir_x10=246, area=1234, conf_x100=47;
    reg [7:0]  ai_score=8'd200;
    reg ai_alive=1, ai_person=0, motion=1, alarm_on=0, night=1, sns_ok=1, low_pwr=0;
    reg dg_lb_scl=0, dg_lb_sda=0;
    reg [7:0] pr_scans=0, pr_cnt=0;
    reg [6:0] pr_a0=0, pr_a1=0;
    reg dg_scl=0, dg_sda=0, dg_slv=0, dg_stuck=0, dg_sht_err=0, dg_ir_err=0,
        dg_sht_seen=0, dg_irseen=0, dg_crc=0;
    reg [15:0] dg_oe_cnt=0, dg_slv_cnt=0;
    reg [7:0] evt_code=0;
    wire txt_we; wire [7:0] txt_wa, txt_wd;

    v7_txt_fmt u_dut (
        .clk(clk), .rst_n(rst_n), .refresh(refresh),
        .temp_x100(temp_x100), .rh_x100(rh_x100), .ir_x10(ir_x10), .area(area), .conf_x100(conf_x100),
        .ai_score(ai_score), .ai_alive(ai_alive), .ai_person(ai_person),
        .motion(motion), .alarm_on(alarm_on), .evt_code(evt_code), .night(night), .sns_ok(sns_ok), .low_pwr(low_pwr),
        .dg_lb_scl(dg_lb_scl), .dg_lb_sda(dg_lb_sda), .pr_scans(pr_scans), .pr_cnt(pr_cnt),
        .pr_a0(pr_a0), .pr_a1(pr_a1),
        .dg_scl(dg_scl), .dg_sda(dg_sda), .dg_slv(dg_slv), .dg_stuck(dg_stuck),
        .dg_sht_err(dg_sht_err), .dg_ir_err(dg_ir_err), .dg_sht_seen(dg_sht_seen),
        .dg_irseen(dg_irseen), .dg_crc(dg_crc),
        .dg_oe_cnt(dg_oe_cnt), .dg_slv_cnt(dg_slv_cnt),
        .txt_we(txt_we), .txt_wa(txt_wa), .txt_wd(txt_wd));

    reg [7:0] cap [128:139];
    integer i, n, errors=0;

    task run_one;
        input [7:0] code;
        input [7:0] a0,a1,a2,a3,a4,a5,a6;
        input [255:0] name;
        begin
            evt_code = code;
            @(posedge clk); refresh<=1; @(posedge clk); refresh<=0;
            n = 0;
            while (n < 400) begin
                @(posedge clk);
                if (txt_we && txt_wa >= 8'd128 && txt_wa <= 8'd138)
                    cap[txt_wa] = txt_wd;
                n = n + 1;
            end
            if (cap[128]==8'd69 && cap[129]==8'd86 && cap[130]==8'd84 && cap[131]==8'd61 &&
                cap[132]==a0 && cap[133]==a1 && cap[134]==a2 && cap[135]==a3 &&
                cap[136]==a4 && cap[137]==a5 && cap[138]==a6) begin
                $display("  PASS %0s: EVT=%c%c%c%c%c%c%c (code=%0d)",
                         name, cap[132],cap[133],cap[134],cap[135],cap[136],cap[137],cap[138], code);
            end else begin
                errors = errors + 1;
                $display("  FAIL %0s: got %02x %02x %02x %02x %02x %02x %02x (code=%0d)",
                         name, cap[132],cap[133],cap[134],cap[135],cap[136],cap[137],cap[138], code);
            end
        end
    endtask

    initial begin
        $display("=== MERGE13 TB: OSD EVT from word14 ===");
        rst_n = 0; repeat(10) @(posedge clk); rst_n = 1; repeat(5) @(posedge clk);

        // 1=INTRUDE I N T R U D E
        alarm_on=0; low_pwr=0;
        run_one(8'd1, 8'd73,8'd78,8'd84,8'd82,8'd85,8'd68,8'd69, "code1 INTRUDE");
        // 2=TREND   T R E N D ' ' ' '
        run_one(8'd2, 8'd84,8'd82,8'd69,8'd78,8'd68,8'd32,8'd32, "code2 TREND");
        // 3=PERSON  P E R S O N ' '
        run_one(8'd3, 8'd80,8'd69,8'd82,8'd83,8'd79,8'd78,8'd32, "code3 PERSON");
        // 4=LOWPWR  L O W P W R ' '
        run_one(8'd4, 8'd76,8'd79,8'd87,8'd80,8'd87,8'd82,8'd32, "code4 LOWPWR");
        // 0/default=NORMAL  N O R M A L ' '
        run_one(8'd0, 8'd78,8'd79,8'd82,8'd77,8'd65,8'd76,8'd32, "code0 NORMAL");
        // 反证：alarm_on=1、low_pwr=1 也不能改变 EVT（EVT 只看 word14）
        alarm_on=1; low_pwr=1;
        run_one(8'd0, 8'd78,8'd79,8'd82,8'd77,8'd65,8'd76,8'd32, "alarm_on=1 code0 still NORMAL");

        #20;
        if (errors==0) $display("=== RESULT: ALL TESTS PASSED ===");
        else           $display("=== RESULT: TESTS FAILED (%0d) ===", errors);
        $finish;
    end
endmodule
