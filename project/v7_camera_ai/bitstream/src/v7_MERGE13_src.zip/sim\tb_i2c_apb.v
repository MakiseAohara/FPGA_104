// MERGE10 testbench: APB -> camera SCCB (i2c_master_ctrl_top) with a simple I2C slave model.
// Slave: 7-bit address 0x30, 16-bit register address, 8-bit data, 2048-byte memory.
// Checks:
//   (a) APB command issued BEFORE boot-ROM sequence completes must be ignored.
//   (b) After ready: write 0x3e00=0x01 is received by the slave; read 0x3e00 -> rdata==0x01.
//   (c) A second command issued while busy must be ignored.
`timescale 1ns/1ps

module tb_i2c_apb;

reg clk = 1'b0;
always #100 clk = ~clk;          // 5 MHz

reg rst_n = 1'b0;

wire scl_pad_o, scl_padoen_o, sda_pad_o, sda_padoen_o;
wire scl_pad_i, sda_pad_i;
wire scl_bus, sda_bus;

reg         apb_req_toggle = 1'b0;
reg         apb_rw         = 1'b0;
reg  [7:0]  apb_dev        = 8'd0;
reg  [15:0] apb_addr       = 16'd0;
reg  [7:0]  apb_wdata      = 8'd0;

wire        busy;
wire        done_toggle;
wire [7:0]  rdata;
wire        ready;

i2c_master_ctrl_top #(
    .DATA_LENGTH (164),
    .I2C_REG_ADDR_WIDTH (16),
    .I2C_DATA_WIDTH (8),
    .I2C_DEVICE_ADDR (8'h60),
    .CLK_DIV (16'h0002)            // small divider: boot ROM finishes fast in sim
) dut (
    .clk (clk),
    .rst_n (rst_n),
    .scl_pad_i (scl_pad_i),
    .scl_pad_o (scl_pad_o),
    .scl_padoen_o (scl_padoen_o),
    .sda_pad_i (sda_pad_i),
    .sda_pad_o (sda_pad_o),
    .sda_padoen_o (sda_padoen_o),
    .apb_req_toggle (apb_req_toggle),
    .apb_rw (apb_rw),
    .apb_dev (apb_dev[7:1]),
    .apb_addr (apb_addr),
    .apb_wdata (apb_wdata),
    .busy (busy),
    .done_toggle (done_toggle),
    .rdata (rdata),
    .ready (ready)
);

// ---------------------------------------------------------------------------
// Open-drain I2C bus
// ---------------------------------------------------------------------------
assign scl_bus = (scl_padoen_o === 1'b0) ? 1'b0 : 1'b1;
assign sda_bus = ((sda_padoen_o === 1'b0) || slave_sda_low) ? 1'b0 : 1'b1;
assign scl_pad_i = scl_bus;
assign sda_pad_i = sda_bus;

// ---------------------------------------------------------------------------
// Clocked I2C slave model (oversampled on clk; ~17 clk per SCL bit)
// ---------------------------------------------------------------------------
reg        slave_sda_low;
reg        prev_scl, prev_sda;
reg [3:0]  bitc;
reg [7:0]  sh;
reg [1:0]  byte_i;
reg [7:0]  dev_q;
reg [7:0]  rhi, rlo;
reg [15:0] cur_a;
reg        reading;
reg        in_txn;
reg [7:0]  outb;
reg [7:0]  mem [0:2047];
reg [7:0]  rxlog [0:7];
integer    rxidx;
integer    k;

integer scl_edges, start_cnt, stop_cnt, ack_cnt, byte_cnt;
integer dbg = 0;

initial begin
    slave_sda_low = 1'b0;
    prev_scl = 1'b1; prev_sda = 1'b1;
    bitc = 0; sh = 0; byte_i = 0; dev_q = 0; rhi = 0; rlo = 0;
    cur_a = 0; reading = 0; in_txn = 0; outb = 0;
    scl_edges = 0; start_cnt = 0; stop_cnt = 0; ack_cnt = 0; byte_cnt = 0;
    for (k = 0; k < 2048; k = k + 1) mem[k] = 8'h00;
    for (k = 0; k < 8; k = k + 1) rxlog[k] = 8'h00;
    rxidx = 0;
end

wire scl_rise = (~prev_scl) &  scl_bus;
wire scl_fall =   prev_scl  & ~scl_bus;
wire sda_fall =   prev_sda  & ~sda_bus;
wire sda_rise = (~prev_sda) &  sda_bus;

always @(posedge clk) begin
    prev_scl <= scl_bus;
    prev_sda <= sda_bus;
end

always @(posedge clk) begin
    if (!rst_n) begin
        slave_sda_low <= 1'b0;
        prev_scl <= 1'b1; prev_sda <= 1'b1;
        bitc <= 0; byte_i <= 0; reading <= 0; in_txn <= 0;
        scl_edges <= 0; start_cnt <= 0; stop_cnt <= 0; ack_cnt <= 0; byte_cnt <= 0;
    end else begin
        if (scl_rise) scl_edges <= scl_edges + 1;

        if (sda_fall && scl_bus) begin                 // START / repeated START
            in_txn  <= 1'b1;
            bitc    <= 0;
            byte_i  <= 0;
            reading <= 1'b0;
            slave_sda_low <= 1'b0;
            start_cnt <= start_cnt + 1;
            rxidx <= 0;
        end else if (sda_rise && scl_bus) begin        // STOP
            in_txn  <= 1'b0;
            bitc    <= 0;
            reading <= 1'b0;
            slave_sda_low <= 1'b0;
            stop_cnt <= stop_cnt + 1;
        end else if (!in_txn) begin
            slave_sda_low <= 1'b0;
        end else begin
            if (scl_rise) begin
                if (!reading) begin
                    if (bitc < 8) begin
                        sh   <= {sh[6:0], sda_bus};
                        bitc <= bitc + 1;
                    end else begin                    // 9th bit -> byte complete
                        bitc <= 0;
                        byte_cnt <= byte_cnt + 1;
                        rxlog[rxidx] <= sh;
                        if (rxidx < 7) rxidx <= rxidx + 1;
                        case (byte_i)
                            2'd0: begin
                                dev_q <= sh;
                                if (sh[7:1] == 7'h30) begin
                                    if (sh[0]) begin
                                        reading <= 1'b1;
                                        outb    <= mem[cur_a[10:0]];
                                    end
                                    byte_i <= 2'd1;
                                end else begin
                                    in_txn <= 1'b0;
                                end
                            end
                            2'd1: begin rhi <= sh; byte_i <= 2'd2; end
                            2'd2: begin rlo <= sh; cur_a <= {rhi, sh}; byte_i <= 2'd3; end
                            2'd3: begin mem[cur_a[10:0]] <= sh; byte_i <= 2'd0; end
                            default: byte_i <= 2'd0;
                        endcase
                    end
                end else begin
                    if (bitc < 8) begin
                        bitc <= bitc + 1;
                    end else begin                        // master ACK/NACK
                        bitc <= 0;
                        if (sda_bus === 1'b1) reading <= 1'b0;
                        else ack_cnt <= ack_cnt + 1;
                    end
                end
            end
            if (scl_fall) begin
                if (reading && bitc < 8)
                    slave_sda_low <= ~outb[7-bitc];   // drive read data bit
                else if (!reading && bitc == 8)
                    slave_sda_low <= 1'b1;            // ACK for received byte
                else
                    slave_sda_low <= 1'b0;
            end
        end
    end
end

// ---------------------------------------------------------------------------
// Test sequence
// ---------------------------------------------------------------------------
integer errors = 0;
integer n;
reg [7:0] mem_600_before;
reg       done_before;
reg [7:0] mem_602_before;

task fail;
    input [1023:0] msg;
    begin
        errors = errors + 1;
        $display("  FAIL: %0s  (t=%0t)", msg, $time);
    end
endtask

task issue_cmd;
    input        rw;
    input [15:0] addr;
    input [7:0]  wd;
    begin
        @(posedge clk);
        #20;
        apb_rw    = rw;
        apb_addr  = addr;
        apb_wdata = wd;
        #40;
        apb_req_toggle = ~apb_req_toggle;
        #40;
    end
endtask

task wait_ready;
    begin
        n = 0;
        while (ready !== 1'b1 && n < 400000) begin
            @(posedge clk);
            n = n + 1;
        end
        if (ready !== 1'b1) fail("boot ROM sequence did not finish (ready timeout)");
        else $display("  boot ROM sequence done: ready=1 after %0d clocks (slave start_cnt=%0d stop_cnt=%0d bytes=%0d scl_edges=%0d)",
                      n, start_cnt, stop_cnt, byte_cnt, scl_edges);
    end
endtask

task wait_done_change;
    reg d0;
    begin
        d0 = done_toggle;
        n  = 0;
        while (done_toggle === d0 && n < 50000) begin
            @(posedge clk);
            n = n + 1;
        end
        if (done_toggle === d0) fail("done_toggle timeout");
    end
endtask

initial begin
    $display("=== MERGE10 TB: APB -> camera SCCB ===");
    rst_n = 1'b0;
    repeat (20) @(posedge clk);
    rst_n = 1'b1;
    repeat (10) @(posedge clk);

    // ---------------- (a) command BEFORE ready must be ignored ----------------
    done_before    = done_toggle;
    issue_cmd(1'b0, 16'h3c5a, 8'h55);       // should be ignored
    $display("  (a) CMD written before ready (addr=0x3c5a data=0x55)");
    wait_ready;
    repeat (20) @(posedge clk);
    if (mem[11'h45a] !== 8'h00)      fail("(a) pre-ready write reached the slave");
    if (start_cnt !== 164)           fail("(a) pre-ready command produced an I2C transaction");
    if (done_toggle !== done_before) fail("(a) pre-ready command produced done_toggle");
    if ((mem[11'h45a] === 8'h00) && (start_cnt == 164) && (done_toggle === done_before))
        $display("  PASS (a) pre-ready CMD ignored (no extra start: start_cnt=164, mem[0x45a]=0)");

    $display("  boot-write sanity: mem[0x126]=0x%02x (ROM entry addr=0x3926 data=0xe0), mem[0x600]=0x%02x",
              mem[11'h126], mem[11'h600]);
    // ---------------- (b) write then read ----------------
    issue_cmd(1'b0, 16'h3e00, 8'h01);
    wait_done_change;
    repeat (10) @(posedge clk);
    $display("  (b1) bus bytes: %02x %02x %02x %02x  (dev=%02x slot=%0d)", rxlog[0], rxlog[1], rxlog[2], rxlog[3], dev_q, byte_i);
    $display("  (b1) after done: mem[0x600]=0x%02x (slave rxlog=%02x %02x %02x %02x)", mem[11'h600], rxlog[0], rxlog[1], rxlog[2], rxlog[3]);
    if (mem[11'h600] !== 8'h01) fail("(b) write 0x3e00=0x01 not seen by slave");
    else $display("  PASS (b1) write 0x3e00=0x01 received by slave");

    issue_cmd(1'b1, 16'h3e00, 8'h00);
    wait_done_change;
    repeat (10) @(posedge clk);
    $display("  (b2) rdata=0x%02x (slave mem[0x600]=0x%02x)  [dbg rd_done=%0b get_data=%02x i2c_readdata=%02x]",
             rdata, mem[11'h600], dut.rd_done, dut.get_data, dut.i2c_readdata);
    if (rdata !== 8'h01) fail("(b) read 0x3e00 returned wrong rdata");
    else $display("  PASS (b2) read 0x3e00 -> rdata=0x%02x", rdata);

    // ---------------- (c) command during busy must be ignored ----------------
    mem_602_before = mem[11'h602];
    issue_cmd(1'b0, 16'h3e01, 8'h02);
    n = 0;
    while (busy !== 1'b1 && n < 400) begin @(posedge clk); n = n + 1; end
    if (busy !== 1'b1) fail("(c) busy never asserted");
    $display("  (c) busy asserted %0d clocks after CMD", n);
    issue_cmd(1'b0, 16'h3e02, 8'h03);       // during busy -> ignored
    wait_done_change;
    repeat (50) @(posedge clk);
    if (mem[11'h601] !== 8'h02)        fail("(c) first write 0x3e01=0x02 missing");
    if (mem[11'h602] !== mem_602_before) fail("(c) second CMD executed during busy");
    if ((mem[11'h601] === 8'h02) && (mem[11'h602] === mem_602_before))
        $display("  PASS (c) CMD during busy ignored (0x3e01=0x02 ok, 0x3e02 untouched)");

    repeat (50) @(posedge clk);
    $display("  slave stats: start_cnt=%0d stop_cnt=%0d scl_edges=%0d bytes=%0d acks=%0d",
             start_cnt, stop_cnt, scl_edges, byte_cnt, ack_cnt);
    if (errors == 0) $display("=== RESULT: ALL TESTS PASSED ===");
    else             $display("=== RESULT: TESTS FAILED, errors=%0d ===", errors);
    $finish;
end

initial begin
    #60_000_000;
    $display("=== RESULT: GLOBAL TIMEOUT ===");
    $finish;
end

endmodule
