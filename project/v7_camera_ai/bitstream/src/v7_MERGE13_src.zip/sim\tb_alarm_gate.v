// MERGE13 新增仿真：报警门控（ir_hot=0、ai_person=1、motion=1 时 alarm_on 拉起）
`timescale 1ns/1ps
module tb_alarm_gate;
    reg alarm_raw=0, motion=0, ir_hot=0, ai_person=0;
    wire gate_ir, gate_noreq;
    integer errors=0;

    v7_alarm_gate #(.REQUIRE_IR(1)) u_ir (
        .alarm_raw(alarm_raw), .motion(motion), .ir_hot(ir_hot),
        .ai_person(ai_person), .alarm_gate(gate_ir));
    v7_alarm_gate #(.REQUIRE_IR(0)) u_noreq (
        .alarm_raw(alarm_raw), .motion(motion), .ir_hot(ir_hot),
        .ai_person(ai_person), .alarm_gate(gate_noreq));

    task check;
        input exp_ir;
        input exp_noreq;
        input [255:0] name;
        begin
            #1;
            if (gate_ir !== exp_ir || gate_noreq !== exp_noreq) begin
                errors = errors + 1;
                $display("  FAIL %0s: ir_gate=%b exp=%b | noreq=%b exp=%b (raw=%b mot=%b ir=%b ai=%b)",
                         name, gate_ir, exp_ir, gate_noreq, exp_noreq, alarm_raw, motion, ir_hot, ai_person);
            end else begin
                $display("  PASS %0s: ir_gate=%b noreq_gate=%b", name, gate_ir, gate_noreq);
            end
        end
    endtask

    initial begin
        $display("=== MERGE13 TB: alarm gate ===");
        // 关键验收用例：ir_hot=0, ai_person=1, motion=1, alarm_raw=1 -> 门控拉起
        alarm_raw=1; motion=1; ir_hot=0; ai_person=1;
        check(1'b1, 1'b1, "ai_person substitutes ir_hot");
        // 无 AI、无红外 -> 不拉
        ai_person=0;
        check(1'b0, 1'b1, "no IR no AI -> blocked (REQUIRE_IR=1)");
        // 只有红外 -> 拉
        ir_hot=1;
        check(1'b1, 1'b1, "ir_hot path");
        // 无运动 -> 不拉
        motion=0; ir_hot=0; ai_person=1;
        check(1'b0, 1'b0, "no motion blocks");
        // alarm_raw=0 -> 不拉
        motion=1; alarm_raw=0; ai_person=1;
        check(1'b0, 1'b0, "alarm_raw=0 blocks");
        // REQUIRE_IR=0 时只要求 motion
        alarm_raw=1; motion=1; ir_hot=0; ai_person=0;
        check(1'b0, 1'b1, "REQUIRE_IR=0 only needs motion");

        #10;
        if (errors==0) $display("=== RESULT: ALL TESTS PASSED ===");
        else           $display("=== RESULT: TESTS FAILED (%0d) ===", errors);
        $finish;
    end
endmodule
